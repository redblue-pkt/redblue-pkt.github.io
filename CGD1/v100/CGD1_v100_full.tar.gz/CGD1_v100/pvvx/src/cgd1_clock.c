#include "cgd1/cgd1_internal.h"

#if defined(CGD1_TELINK) || defined(CGD1_USE_PVVX_CALENDAR)
#ifdef CGD1_TELINK
#include "app_config.h"
typedef uint8_t u8;
typedef uint32_t u32;
#endif
#include "rtc.h"

uint32_t cgd1_calendar_to_epoch(struct cgd1_calendar *date)
{
	rtc_time_t value;
	value.year = date->year >= 2000 ? date->year - 2000 : date->year - 1900;
	value.month = date->month;
	value.days = date->day;
	value.hours = date->hour;
	value.minutes = date->minute;
	value.seconds = date->second;
	uint32_t epoch = rtc_to_utime(&value);
	return date->year >= 2000 ? epoch : epoch - 3155760000u;
}

void cgd1_epoch_to_calendar(uint32_t epoch, struct cgd1_calendar *date)
{
	rtc_time_t value;
	utime_to_rtc(epoch, &value);
	date->year = value.year + (epoch >= 946684800u ? 2000 : 1744);
	date->month = value.month;
	date->day = value.days;
	date->hour = value.hours;
	date->minute = value.minutes;
	date->second = value.seconds;
}
#else
static const uint8_t month_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
static bool leap_year(uint32_t year)
{
	return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
}
uint32_t cgd1_calendar_to_epoch(struct cgd1_calendar *date)
{
	uint32_t days = 0;
	uint32_t year;
	uint32_t month;
	for (year = 1970; year < date->year; year++)
	{
		days += leap_year(year) ? 366 : 365;
	}
	for (month = 1; month < date->month; month++)
	{
		days += month_days[month - 1];
		if (month == 2 && leap_year(date->year))
		{
			days++;
		}
	}
	days += date->day - 1;
	return (int)(days * 86400u + date->hour * 3600u + date->minute * 60u + date->second);
}
void cgd1_epoch_to_calendar(uint32_t epoch, struct cgd1_calendar *date)
{
	uint32_t days = epoch / 86400u;
	uint32_t seconds = epoch % 86400u;
	uint32_t year = 1970;
	uint32_t month = 1;
	uint32_t length;
	while (days >= (length = leap_year(year) ? 366u : 365u))
	{
		days -= length;
		year++;
	}
	for (;;)
	{
		length = month_days[month - 1];
		if (month == 2 && leap_year(year))
		{
			length++;
		}
		if (days < length)
		{
			break;
		}
		days -= length;
		month++;
	}
	date->year = year;
	date->month = month;
	date->day = days + 1;
	date->hour = seconds / 3600u;
	date->minute = seconds % 3600u / 60u;
	date->second = seconds % 60u;
}

#endif

void cgd1_rtc_to_calendar(struct cgd1_rtc_time *rtc, struct cgd1_calendar *date)
{
	date->year = rtc->year_since_2000 + 2000;
	date->month = rtc->month;
	date->day = rtc->day;
	date->hour = rtc->hour;
	date->minute = rtc->minute;
	date->second = rtc->second;
}

void cgd1_calendar_to_rtc(struct cgd1_calendar *date, struct cgd1_rtc_time *rtc)
{
	rtc->year_since_2000 = date->year - 2000;
	rtc->month = date->month;
	rtc->day = date->day;
	rtc->hour = date->hour;
	rtc->minute = date->minute;
	rtc->second = date->second;
	rtc->weekday = cgd1_calendar_weekday(date->year, date->month, date->day);
}

uint32_t cgd1_alarm_next_one_shot_epoch(struct cgd1_rtc_time *now, uint8_t hour, uint8_t minute)
{
	struct cgd1_rtc_time target = *now;
	struct cgd1_calendar date;
	target.hour = hour;
	target.minute = minute;
	target.second = 0;
	cgd1_rtc_to_calendar(&target, &date);
	uint32_t epoch = cgd1_calendar_to_epoch(&date);
	if (hour < now->hour || (hour == now->hour && minute <= now->minute))
	{
		epoch += 86400;
	}
	return epoch;
}

uint8_t cgd1_calendar_weekday(int year, int month, int day)
{
	static const uint8_t weekday_translation[7] = {1, 2, 3, 4, 5, 6, 0};
	if ((uint32_t)(month - 1) < 2)
	{
		month += 12;
		year--;
	}
	int index =
		(year + day + month * 2 + year / 4 - year / 100 + year / 400 + (month + 1) * 3 / 5) % 7;
	return (uint32_t)index < 7 ? weekday_translation[index] : 1;
}


void cgd1_epoch_to_rtc(uint32_t epoch, struct cgd1_rtc_time *result)
{
#if defined(CGD1_TELINK) || defined(CGD1_USE_PVVX_CALENDAR)
	rtc_time_t value;
	utime_to_rtc(epoch, &value);
	result->year_since_2000 = value.year;
	if (epoch < 946684800u)
		result->year_since_2000 = (uint16_t)(value.year - 256);
	result->month = value.month;
	result->day = value.days;
	result->hour = value.hours;
	result->minute = value.minutes;
	result->second = value.seconds;
	result->weekday = value.weekday;
#else
	struct cgd1_calendar date;
	cgd1_epoch_to_calendar(epoch, &date);
	cgd1_calendar_to_rtc(&date, result);
#endif
}
