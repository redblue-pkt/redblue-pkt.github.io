#ifndef CGD1_H
#define CGD1_H

#ifdef CGD1_TELINK
#include "tl_common.h"
#else
#include <stdbool.h>
#include <stddef.h>
#endif
#include <stdint.h>

/* GPIO encoding is the Telink SDK encoding: port << 8 | pin mask. */
#define CGD1_I2C_SDA 0x0204u
#define CGD1_I2C_SCL 0x0208u
#define CGD1_FLASH_CS 0x0304u
#define CGD1_FLASH_CLK 0x0380u
#define CGD1_FLASH_MISO 0x0140u
#define CGD1_FLASH_MOSI 0x0180u
#define CGD1_BACKLIGHT 0x0308u
#define CGD1_AUDIO_PWM0 0x0202u
#define CGD1_AUDIO_PWM4_N 0x0201u
#define CGD1_AUDIO_ENABLE 0x0310u
#define CGD1_BUTTON_TOP 0x0002u
#define CGD1_INPUT_PA0 0x0001u
#define CGD1_INPUT_PB1 0x0102u
#define CGD1_BATTERY_ADC 0x0210u
#define CGD1_REVISION_STRAPS 0x0130u
#define CGD1_SWS 0x0080u
#define CGD1_AUDIO_SLOT_A 0x00000ul
#define CGD1_AUDIO_SLOT_B 0x80000ul
#define CGD1_AUDIO_MAX 0x80000ul
#define CGD1_AUDIO_RATE 8000u
#define CGD1_AUDIO_BLOCK 512u
#define CGD1_AUDIO_PACKET 128u
#define CGD1_LCD_BYTES 18u

enum cgd1_lcd_model {
	CGD1_BU9792,
	CGD1_HT9B92
};

enum cgd1_sensor_model {
	CGD1_SENSOR_NONE,
	CGD1_SHTC3,
	CGD1_SHT4X
};

enum cgd1_rtc_model {
	CGD1_RTC_LEGACY,
	CGD1_RTC_REV2
};

/* All callbacks return 0 on success. Addresses below are seven-bit.
 * xfer sends tx, repeated START if rx is requested, then STOP.
 * spi is one complete CS-low transaction, including command/address.
 * A platform must serialize I2C and SPI users; callbacks may not recurse.
 */
struct cgd1_hal {
	void *context;
	int (*i2c)(void *, uint8_t, const uint8_t *, size_t, uint8_t *, size_t);
	int (*spi)(void *, const uint8_t *, size_t, uint8_t *, size_t);
	void (*delay_us)(void *, uint32_t);
	void (*backlight)(void *, uint8_t);
};

struct cgd1_time {
	uint8_t year;
	uint8_t month;
	uint8_t day;
	uint8_t weekday;
	uint8_t hour;
	uint8_t minute;
	uint8_t second;
};

struct cgd1 {
	struct cgd1_hal hal;
	uint8_t model;
	uint8_t sensor;
	uint8_t rtc_model;
#ifdef CGD1_TELINK
	uint8_t *lcd;
	uint8_t *lcd_sent;
#else
	uint8_t lcd[18];
	uint8_t lcd_sent[18];
#endif
	bool lcd_valid;
	bool sensor_pending;
	uint32_t flash_capacity;
};

void cgd1_setup(struct cgd1 *, const struct cgd1_hal *, enum cgd1_lcd_model,
	enum cgd1_rtc_model);
int cgd1_lcd_init(struct cgd1 *);
#include "cgd1_crc.h"
int cgd1_lcd_flush(struct cgd1 *, bool);
void cgd1_lcd_segment(struct cgd1 *, uint8_t, uint8_t, bool);
void cgd1_lcd_digit(struct cgd1 *, uint8_t, uint8_t);
int cgd1_lcd_measurement(struct cgd1 *, int16_t, uint16_t, bool);
void cgd1_lcd_bluetooth(struct cgd1 *, bool);
void cgd1_lcd_battery(struct cgd1 *, bool);
uint8_t cgd1_crc8(const uint8_t *, size_t);
int cgd1_sensor_probe(struct cgd1 *);
int cgd1_sensor_start(struct cgd1 *);
int cgd1_sensor_read(struct cgd1 *, int16_t *, uint16_t *);
int cgd1_rtc_init(struct cgd1 *);
int cgd1_rtc_read(struct cgd1 *, struct cgd1_time *);
int cgd1_rtc_write(struct cgd1 *, const struct cgd1_time *);
int cgd1_flash_id(struct cgd1 *, uint8_t[3]);
int cgd1_flash_read(struct cgd1 *, uint32_t, uint8_t *, size_t);
int cgd1_flash_erase(struct cgd1 *, uint32_t);
int cgd1_flash_write(struct cgd1 *, uint32_t, const uint8_t *, size_t);

#endif
