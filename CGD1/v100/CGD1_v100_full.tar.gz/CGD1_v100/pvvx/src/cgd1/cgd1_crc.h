#ifndef CGD1_CRC_H
#define CGD1_CRC_H
#include <stdint.h>
uint16_t cgd1_settings_crc(const uint8_t *data, unsigned size, unsigned offset);
uint32_t cgd1_crc32_update(uint32_t crc, const uint8_t *data, unsigned size);
#endif
