#ifndef CGD1_AUDIO_H
#define CGD1_AUDIO_H
#include <stdint.h>
#include "../decoders/decoder_config.h"

#define CGD1_AUDIO_HEADER 24u
#define CGD1_CODEC_MASK (0u \
	CGD1_PCM8_MASK CGD1_PCM16_MASK CGD1_ADPCM_MASK CGD1_ALAW_MASK CGD1_ULAW_MASK \
	CGD1_G722_MASK CGD1_AMR_MASK CGD1_SBC_MASK CGD1_MSBC_MASK)
#ifdef DECODER_PCM8
#define CGD1_PCM8_MASK | (1u << 1)
#else
#define CGD1_PCM8_MASK
#endif
#ifdef DECODER_PCM16
#define CGD1_PCM16_MASK | (1u << 2)
#else
#define CGD1_PCM16_MASK
#endif
#ifdef DECODER_ADPCM
#define CGD1_ADPCM_MASK | (1u << 3)
#else
#define CGD1_ADPCM_MASK
#endif
#ifdef DECODER_ALAW
#define CGD1_ALAW_MASK | (1u << 4)
#else
#define CGD1_ALAW_MASK
#endif
#ifdef DECODER_ULAW
#define CGD1_ULAW_MASK | (1u << 5)
#else
#define CGD1_ULAW_MASK
#endif
#ifdef DECODER_G722
#define CGD1_G722_MASK | (1u << 8)
#else
#define CGD1_G722_MASK
#endif
#ifdef DECODER_AMR
#define CGD1_AMR_MASK | (1u << 9)
#define CGD1_PCM_BUFFER 320
#else
#define CGD1_AMR_MASK
#define CGD1_PCM_BUFFER 128
#endif
#ifdef DECODER_SBC
#define CGD1_SBC_MASK | (1u << 10)
#else
#define CGD1_SBC_MASK
#endif
#ifdef DECODER_MSBC
#define CGD1_MSBC_MASK | (1u << 11)
#else
#define CGD1_MSBC_MASK
#endif
#if defined(DECODER_SBC) || defined(DECODER_MSBC)
#define CGD1_DECODER_WORDS 192
#elif defined(DECODER_G722)
#define CGD1_DECODER_WORDS 128
#elif defined(DECODER_ADPCM)
#define CGD1_DECODER_WORDS 4
#else
#define CGD1_DECODER_WORDS 1
#endif
struct cgd1_audio_decoder {
	/* SDK uses -fpack-struct: explicit alignment is required for TC32
	 * word accesses. This private state is never stored or sent on BLE. */
	int (*read)(void *, uint32_t, uint8_t *, unsigned) __attribute__((aligned(4)));
	void *context __attribute__((aligned(4)));
	uint32_t size __attribute__((aligned(4)));
	uint32_t rate __attribute__((aligned(4)));
	uint32_t frames __attribute__((aligned(4)));
	uint32_t frame __attribute__((aligned(4)));
	uint32_t offset __attribute__((aligned(4)));
	uint32_t data_offset __attribute__((aligned(4)));
	uint32_t cache_offset __attribute__((aligned(4)));
	unsigned cache_size __attribute__((aligned(4)));
	uint32_t state[CGD1_DECODER_WORDS] __attribute__((aligned(4)));
	int16_t pcm[CGD1_PCM_BUFFER] __attribute__((aligned(4)));
	unsigned pcm_count __attribute__((aligned(4)));
	unsigned pcm_pos __attribute__((aligned(4)));
	uint8_t codec, cache[512];

} __attribute__((aligned(4)));
int cgd1_audio_stream_init(struct cgd1_audio_decoder *, unsigned, uint32_t);
int cgd1_audio_stream_decode(struct cgd1_audio_decoder *, const uint8_t *, unsigned, unsigned *, int16_t *, unsigned);
int cgd1_audio_open(struct cgd1_audio_decoder *, int (*)(void *, uint32_t, uint8_t *, unsigned), void *, uint32_t);
int cgd1_audio_rewind(struct cgd1_audio_decoder *);
int cgd1_audio_decode16(struct cgd1_audio_decoder *, uint16_t *, unsigned);
int cgd1_audio_decode(struct cgd1_audio_decoder *, uint8_t *, unsigned);
#endif
