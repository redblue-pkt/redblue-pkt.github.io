#ifndef CGD1_APP_INTERNAL_H
#define CGD1_APP_INTERNAL_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "cgd1_app.h"

enum cgd1_alarm_event_type
{
	CGD1_ALARM_RINGING = 0,
	CGD1_ALARM_SNOOZED = 1,
	CGD1_ALARM_RINGING_AFTER_SNOOZE = 2
};
struct __attribute__((packed)) cgd1_alarm_event
{
	uint8_t enabled;
	uint8_t slot;
	uint32_t timestamp;
	uint8_t event_type;
};
struct __attribute__((packed)) cgd1_alarm_slot
{
	uint8_t enabled;
	uint8_t hour;
	uint8_t minute;
	uint8_t repeat_raw;
	uint8_t flags_raw;
	uint32_t timestamp;
};
struct __attribute__((packed)) cgd1_alarm_state
{
	struct cgd1_alarm_event events[16];
	struct cgd1_alarm_slot slots[16];
};
struct __attribute__((packed)) cgd1_alarm_storage_record
{
	uint8_t marker;
	uint16_t crc;
	struct cgd1_alarm_slot slots[16];
};
struct __attribute__((packed)) cgd1_system_parameters
{
	uint8_t valid_marker;
	uint8_t audio_volume;
	uint16_t audio_play_time;
	uint8_t chinese_language;
	uint8_t hour_system_24;
	uint8_t celsius;
	uint8_t automatic_time_correction;
	uint8_t alarms_all_off;
	uint8_t night_start_hour;
	uint8_t night_start_minute;
	uint8_t night_end_hour;
	uint8_t night_end_minute;
	uint32_t audio_data_signature;
	uint8_t timezone_magnitude;
	uint8_t led_on_time;
	uint8_t led_brightness;
	uint8_t timezone_sign_flags;
	uint8_t reserved_15[2];
	uint32_t audio_file_size;
	uint8_t reserved_1b;
	int8_t tx_power_dbm;
	uint16_t ble_adv_interval;
	uint8_t reserved_1f[16];
	uint16_t crc;
};

struct __attribute__((packed)) cgd1_rtc_time
{
	uint16_t year_since_2000;
	uint8_t month;
	uint8_t day;
	uint8_t weekday;
	uint8_t hour;
	uint8_t minute;
	uint8_t second;
};
struct cgd1_calendar
{
	uint16_t year;
	uint16_t month;
	uint16_t day;
	uint16_t hour;
	uint16_t minute;
	uint16_t second;
};
struct __attribute__((packed)) cgd1_button_state
{
	uint8_t level;
	uint8_t previous_level;
	uint8_t press_count;
	uint8_t first_press_seen;
	uint32_t released_ticks;
	uint32_t pressed_ticks;
	uint8_t counted_presses;
	uint8_t multi_press_seen;
	uint8_t short_press_seen;
	uint8_t hold_2_seconds_seen;
	uint8_t hold_6_seconds_seen;
	uint8_t hold_20_seconds_seen;
	uint8_t scanning;
	uint8_t scan_pending;
	uint8_t wakeup_pending;
	uint8_t sampled_level;
	uint8_t previous_sample;
	uint8_t reserved_17;
	uint32_t scan_timestamp;
};

struct cgd1_app_state {
	struct cgd1_rtc_time time;
	struct cgd1_rtc_time displayed_time;
	struct cgd1_rtc_time next_alarm;
	struct cgd1_button_state button;
	struct cgd1_alarm_state alarms;
	struct cgd1_system_parameters config;
	uint8_t audio_playing;
#ifdef CGD1_TELINK
	uint8_t *lcd;
#else
	uint8_t lcd[18];
#endif
	uint8_t revision, lcd_driver, screen, screen_locked, rtc_init_retries;
	uint8_t sensors_hidden, date_hidden, colon_enabled, colon_falling;
	uint16_t colon_ms __attribute__((aligned(2)));
	uint16_t last_temperature __attribute__((aligned(2)));
	uint32_t last_humidity __attribute__((aligned(4)));
	int16_t raw_temperature __attribute__((aligned(2)));
	uint16_t raw_humidity __attribute__((aligned(2)));
	uint16_t display_temperature __attribute__((aligned(2)));
	uint16_t display_humidity __attribute__((aligned(2)));
	uint8_t bluetooth_blink, bluetooth_count, bluetooth_mode;
	uint8_t next_mode, next_valid, minute_repeated, minute;
	uint8_t inhibited, shutdown, light_ticks, light_requested;
	uint8_t alarm_active, binding_mode, advertising, binding_complete;
};
extern struct cgd1_app_state cgd1_state;
void cgd1_epoch_to_rtc(uint32_t epoch, struct cgd1_rtc_time *rtc);
extern uint8_t controller_state, last_celsius;
extern const uint8_t cgd1_digit_bits[2][16][7];
extern const uint8_t cgd1_digit_glyphs[10];
struct cgd1_lcd_overlay
{
	uint8_t and_mask[4];
	uint8_t or_mask[4];
};
extern const struct cgd1_lcd_overlay cgd1_weekday_masks[2][4][8];
typedef struct cgd1_rtc_time cgd1_rtc_time;
typedef struct cgd1_calendar cgd1_calendar;
typedef struct cgd1_alarm_event cgd1_alarm_event;
typedef struct cgd1_alarm_slot cgd1_alarm_slot;
typedef struct cgd1_alarm_storage_record cgd1_alarm_storage_record;
typedef struct cgd1_alarm_state cgd1_alarm_state;
typedef struct cgd1_system_parameters cgd1_system_parameters;
typedef uint32_t (*cgd1_timer_callback_t)(void);
void cgd1_key_first_press(void);
void cgd1_key_double_press(void);
uint32_t cgd1_weekday_monday_one(uint32_t weekday);
bool cgd1_board_uses_at8372(void);
int cgd1_rtc_initialization_ready(void);
int cgd1_app_epoch(void);
void cgd1_power_lock(uint32_t reason);
void cgd1_power_unlock(uint32_t reason);
uint32_t cgd1_soft_timer_add(cgd1_timer_callback_t callback, int period);
uint32_t cgd1_soft_timer_remove_callback(cgd1_timer_callback_t callback);
uint32_t cgd1_display_flush(void);
uint8_t cgd1_audio_is_playing(void);
void cgd1_sound_stop(void);
void cgd1_ble_stop_advertising(void);
void cgd1_ble_set_binding_mode(char enabled);
uint8_t cgd1_ble_get_binding_mode(void);
void cgd1_lcd_cancel_alarm_blink(void);
void cgd1_alarm_start_sound_and_light(void);
void cgd1_binding_begin_with_blink(void);
uint32_t cgd1_ble_enqueue_deferred_callback(void (*callback)(void));
uint32_t cgd1_disconnect(uint32_t reason);
void cgd1_user_data_reset(void);
void cgd1_binding_clear_and_reboot(void);
uint32_t cgd1_i2c_initialize(void);
void cgd1_app_init(uint8_t revision);
void cgd1_app_configure(const struct cgd1_app_config *c);
void cgd1_app_time(uint32_t epoch, uint8_t ready);
void cgd1_app_measurement(int16_t temperature, uint16_t humidity, uint8_t valid);
void cgd1_app_audio_press(void);
void cgd1_app_button_irq(void);
void cgd1_app_button_poll(void);
void cgd1_app_poll(uint8_t connected, uint8_t playing);
void cgd1_app_audio_stopped(void);
void cgd1_app_audio_finished(void);
void cgd1_app_alarm_set(unsigned index, const struct cgd1_app_alarm *a);
void cgd1_app_alarm_get(unsigned index, struct cgd1_app_alarm *a);
void cgd1_app_master(uint8_t enabled);
void cgd1_app_cancel(void);
void cgd1_app_copy_lcd(uint8_t *output);
void cgd1_app_second(void);
void cgd1_app_wake_light(void);
uint8_t cgd1_app_screen(void);
uint8_t cgd1_app_busy(void);
uint8_t cgd1_app_event(void);
uint8_t cgd1_app_runtime(unsigned index, uint32_t *timestamp);
uint32_t cgd1_app_snooze(void);
uint32_t cgd1_app_alarm_stamp(uint8_t hour, uint8_t minute);
uint32_t cgd1_app_next(void);
uint16_t cgd1_app_battery(uint16_t sample);
uint8_t cgd1_app_battery_low(void);
uint8_t cgd1_app_battery_level(void);
void cgd1_app_records(uint8_t settings[49], uint8_t alarms[147], uint32_t length, uint32_t crc);
uint8_t cgd1_app_brightness(void);
uint32_t cgd1_calendar_to_epoch(struct cgd1_calendar *date);
void cgd1_epoch_to_calendar(uint32_t epoch, struct cgd1_calendar *date);
void cgd1_rtc_to_calendar(struct cgd1_rtc_time *rtc, struct cgd1_calendar *date);
void cgd1_calendar_to_rtc(struct cgd1_calendar *date, struct cgd1_rtc_time *rtc);
uint32_t cgd1_alarm_next_one_shot_epoch(struct cgd1_rtc_time *now, uint8_t hour, uint8_t minute);
uint8_t cgd1_calendar_weekday(int year, int month, int day);
uint32_t cgd1_alarm_remove_events(uint8_t slot);
uint8_t cgd1_alarm_count_event_type1(void);
uint8_t cgd1_alarm_count_event_type2(void);
uint8_t cgd1_alarm_count_snoozable_ringing(void);
uint32_t cgd1_alarm_clear_pending_events(void);
void cgd1_alarm_refresh_icon(void);
uint32_t cgd1_alarm_expire_entries(void);
uint32_t cgd1_alarm_disable_slot(int16_t slot);
uint32_t cgd1_alarm_finish_events(char preserve_snoozable);
void cgd1_alarm_switch_all_off(char persist);
void cgd1_alarm_switch_all_on(char persist);
uint32_t cgd1_alarm_find_next(struct cgd1_rtc_time *output, uint32_t epoch, uint32_t day_offset, uint8_t *found);
bool cgd1_alarm_get_next(uint8_t *output, uint32_t epoch, uint32_t day_offset);
void cgd1_alarm_show_next(char mode);
uint32_t cgd1_alarm_add_event(char slot, uint8_t event_type);
uint8_t cgd1_alarm_valid_slot_count(struct cgd1_alarm_slot *filter_slots, uint8_t enabled_only);
void cgd1_alarm_evaluate_minute(struct cgd1_rtc_time *now);
void cgd1_alarm_clear_ringing_events(void);
void cgd1_alarm_snooze(int16_t selection);
uint32_t cgd1_alarm_stop_non_snoozable(void);
uint32_t cgd1_alarm_stop_events(char preserve_snoozable);
uint32_t cgd1_alarm_disable_active_slots(char non_snoozable_only);
void cgd1_on_audio_started(void);
void cgd1_on_audio_finished(void);
void cgd1_key_stop(void);
void cgd1_on_short_press(void);
void cgd1_key_cancel(char wake_light);
void cgd1_on_hold_2_seconds(void);
void cgd1_on_hold_6_seconds(void);
void cgd1_on_press_sequence_finished(void);
void cgd1_on_factory_reset(void);
void cgd1_on_alarm_triggered(uint32_t slot, char resumed);
void cgd1_on_alarm_finished(void);
void cgd1_on_ble_connected(void);
void cgd1_binding_end(void);
uint32_t cgd1_button_update_state(uint8_t level);
void cgd1_button_debounce_poll(void);
void cgd1_button_wakeup_irq(char forced);
void cgd1_button_begin_scan(void);
void cgd1_button_scan_task(void);
uint8_t cgd1_led_get_brightness(void);
uint32_t cgd1_led_timeout_callback(void);
void cgd1_led_turn_on(char seconds_override, uint32_t brightness);
void cgd1_led_turn_off(void);
void cgd1_app_preview_light(uint8_t level);
void cgd1_lcd_set_cell(uint32_t common, uint32_t segment, char enabled);
uint32_t cgd1_lcd_draw_digit(uint32_t position, uint8_t digit);
uint32_t cgd1_lcd_show_weekday(uint8_t weekday, uint32_t language);
void cgd1_lcd_clear_date(char clear_extra_symbol);
void cgd1_lcd_show_date(uint32_t year, uint32_t month, uint32_t day, char clear_extra_symbol);
uint32_t cgd1_lcd_show_time(uint32_t hour, uint32_t minute, char mode_24_hours);
uint32_t cgd1_lcd_show_datetime(struct cgd1_rtc_time time, uint32_t language, uint8_t mode_24_hours);
void cgd1_lcd_sensor_error_1(void);
void cgd1_lcd_sensor_error_2(char celsius);
void cgd1_lcd_clear_sensor_values(void);
void cgd1_lcd_show_sensor_values(int16_t temperature_tenths, uint16_t humidity_tenths, uint8_t celsius, uint8_t force_refresh);
void cgd1_lcd_set_bell(char enabled);
void cgd1_lcd_set_bluetooth(char enabled);
void cgd1_lcd_show_invalid_time(void);
void cgd1_lcd_colon_tick(uint16_t elapsed_ms);
void cgd1_lcd_update_bluetooth(void);
uint32_t cgd1_lcd_bluetooth_blink_tick(void);
bool cgd1_lcd_binding_blink_start(void);
bool cgd1_lcd_activity_blink_start(void);
void cgd1_lcd_snooze_label(uint8_t enabled, uint8_t language);
void cgd1_lcd_stop_label(uint8_t enabled, uint8_t language);
void cgd1_lcd_hide_sensor_values(char flush);
void cgd1_lcd_restore_sensor_values(char flush);
void cgd1_lcd_hide_date(char flush, char clear_symbol);
uint32_t cgd1_lcd_restore_date(char flush, char show_symbol);
void cgd1_lcd_colon_blink_enable(void);
void cgd1_lcd_colon_blink_disable(void);
void cgd1_lcd_clear(void);
void cgd1_lcd_fill(void);
uint8_t cgd1_ui_get_screen(void);
uint32_t cgd1_ui_show_clock(void);
void cgd1_ui_show_non_snoozable_alarm(void);
void cgd1_ui_show_snoozable_alarm(void);
void cgd1_ui_show_snooze_wait(void);
uint32_t cgd1_ui_show_next_alarm(void);
void cgd1_ui_show_all_segments_locked(void);
void cgd1_ui_redraw(void);
uint32_t cgd1_hw_irq_source(void);
void cgd1_key_irq_rearm(void);
void cgd1_key_irq_mask(void);
#endif
