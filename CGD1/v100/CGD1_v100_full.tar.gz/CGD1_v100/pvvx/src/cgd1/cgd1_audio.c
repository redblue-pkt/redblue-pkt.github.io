#include "cgd1_audio.h"
#include "cgd1_crc.h"
#include "../decoders/decoder.h"
#include "../decoders/libpcm.h"
#include "../decoders/libadpcm.h"
#include "../decoders/libg711.h"
#include "../decoders/libg722.h"
#include "../decoders/libamr.h"
#include "../decoders/libsbc.h"
#include "../decoders/libmsbc.h"
#define AUDIO_RAM __attribute__((section(".ram_code")))
static AUDIO_RAM int decode_frame(struct decoder_frame *f)
{
	switch (f->codec) {
#if defined(DECODER_PCM8) || defined(DECODER_PCM16)
#ifdef DECODER_PCM8
	case AUDIO_PCM8:
#endif
#ifdef DECODER_PCM16
	case AUDIO_PCM16:
#endif
		return libpcm_decode(f);
#endif
#if defined(DECODER_ADPCM)
	case AUDIO_IMA:
		return libadpcm_decode(f);
#endif
#if defined(DECODER_ALAW) || defined(DECODER_ULAW)
#ifdef DECODER_ALAW
	case AUDIO_ALAW:
#endif
#ifdef DECODER_ULAW
	case AUDIO_ULAW:
#endif
		return libg711_decode(f);
#endif
#if defined(DECODER_G722)
	case AUDIO_G722:
		return libg722_decode(f);
#endif
#if defined(DECODER_AMR)
	case AUDIO_AMR:
		return libamr_decode(f);
#endif
#if defined(DECODER_SBC)
#ifdef DECODER_SBC
	case AUDIO_SBC:
#endif
		return libsbc_decode(f);
#endif
#if defined(DECODER_MSBC)
	case AUDIO_MSBC:
		return libmsbc_decode(f);
#endif
	default:
		return -1;
	}
}
static uint32_t u32(const uint8_t *p)
{
	return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}
static AUDIO_RAM int refill(struct cgd1_audio_decoder *d);
/* Framed formats identify themselves. Raw PCM/IMA/G.711 require metadata. */
static int open_framed(struct cgd1_audio_decoder *d, unsigned codec)
{
	struct decoder_frame f;
	memset(&f, 0, sizeof(f));
	f.codec = codec;
	f.channels = 1;
	f.flags = DECODER_PROBE;
	d->frames = 0;
	d->offset = 0;
	while (d->offset < d->size) {
		int count = refill(d);
		if (count <= 0)
			return -1;
		f.input = d->cache + d->offset - d->cache_offset;
		f.input_size = count;
		f.input_used = f.output_used = 0;
		int result = decode_frame(&f);
		if (result == -2 && d->offset > d->cache_offset) {
			d->cache_size = 0;
			continue;
		}
		if (result != 1 || !f.input_used || f.input_used > (unsigned)count)
			return -1;
		d->offset += f.input_used;
		d->frames += f.output_used;
	}
	d->codec = codec;
	d->rate = f.rate;
	d->offset = codec == AUDIO_AMR ? (f.rate == 8000 ? 6 : 9) : 0;
	d->cache_size = 0;
	return d->frames ? 0 : -1;
}
int cgd1_audio_open(struct cgd1_audio_decoder *d,
	int (*read)(void *, uint32_t, uint8_t *, unsigned), void *context, uint32_t size)
{
	uint8_t h[24];
	uint32_t bytes;
	if (!size || !read)
		return -1;
	memset(d, 0, sizeof(*d));
	d->read = read;
	d->context = context;
	d->size = size;
	d->codec = AUDIO_PCM8;
	d->rate = 8000;
	d->frames = size;
	if (size >= 4) {
		if (read(context, 0, h, 4))
			return -1;
		if (!memcmp(h, "#!AM", 4)) {
			if (open_framed(d, AUDIO_AMR))
				return -1;
		} else if (h[0] == 0x9c || h[0] == 0xad) {
			if (open_framed(d, h[0] == 0xad ? AUDIO_MSBC : AUDIO_SBC)) {
				if (d->frames)
					return -1;
				/* Untagged PCM8 may start with the same byte. */
				d->codec = AUDIO_PCM8;
				d->rate = 8000;
				d->frames = size;
				d->offset = d->cache_size = 0;
			}
		} else if (!memcmp(h, "CGDA", 4)) {
			if (size < sizeof(h) || read(context, 0, h, sizeof(h)))
				return -1;
			d->codec = h[5];
			d->rate = u32(h + 8);
			d->frames = u32(h + 12);
			bytes = u32(h + 16);
			if (h[4] != 1 || h[6] != 1 || h[7] || (cgd1_crc32_update(0xffffffff, h, 20) ^ 0xffffffff) != u32(h + 20)
				|| !d->frames || d->rate < 4000 || d->rate > DECODER_MAX_RATE
				|| bytes != size - sizeof(h))
				return -1;
			unsigned width = d->codec == AUDIO_PCM16 ? 2 : 1;
			if (d->codec == AUDIO_IMA) {
				if (d->frames / 2 + (d->frames & 1) != bytes)
					return -1;
			} else if (d->codec == AUDIO_G722) {
				if (d->frames != bytes && d->frames != bytes * 2u)
					return -1;
				/* Standard G.722 always reconstructs 16 kHz PCM. */
				d->rate = 16000;
				d->frames = bytes * 2u;
			} else if (d->codec <= AUDIO_ULAW) {
				if (d->frames > bytes / width || d->frames * width != bytes)
					return -1;
			}
			d->offset = sizeof(h);
		}
	}
	d->data_offset = d->offset;
	return cgd1_audio_rewind(d);
}
AUDIO_RAM int cgd1_audio_rewind(struct cgd1_audio_decoder *d)
{
	d->offset = d->data_offset;
	d->frame = d->cache_size = d->pcm_pos = d->pcm_count = 0;
	struct decoder_frame f;
	memset(&f, 0, sizeof(f));
	f.codec = d->codec;
	f.rate = d->rate;
	f.channels = 1;
	f.state = d->state;
	f.flags = DECODER_INIT | DECODER_LEGACY_IMA;
	return decode_frame(&f) == 1 ? 0 : -1;
}
static AUDIO_RAM int refill(struct cgd1_audio_decoder *d)
{
	if (d->offset >= d->size)
		return 0;
	if (d->cache_size && d->offset >= d->cache_offset
		&& d->offset < d->cache_offset + d->cache_size)
		return d->cache_size - (d->offset - d->cache_offset);
	d->cache_offset = d->offset;
	d->cache_size = d->size - d->offset;
	if (d->cache_size > sizeof(d->cache))
		d->cache_size = sizeof(d->cache);
	if (d->read(d->context, d->offset, d->cache, d->cache_size))
		return -1;
	return d->cache_size;
}
AUDIO_RAM int cgd1_audio_decode16(struct cgd1_audio_decoder *d, uint16_t *out, unsigned count)
{
	unsigned n = 0;
	while (n < count && d->frame < d->frames) {
		if (d->pcm_pos == d->pcm_count) {
			int available = refill(d);
			if (available < 0)
				return -1;
			struct decoder_frame f;
			memset(&f, 0, sizeof(f));
			f.codec = d->codec;
			f.rate = d->rate;
			f.channels = 1;
			f.state = d->state;
			f.flags = DECODER_LEGACY_IMA;
			f.input = d->cache + d->offset - d->cache_offset;
			f.input_size = available;
			f.output = d->pcm;
			f.output_size = d->frames - d->frame;
			if (f.output_size > CGD1_PCM_BUFFER)
				f.output_size = CGD1_PCM_BUFFER;
			int result = decode_frame(&f);
			if (result == -2 && available && d->offset > d->cache_offset) {
				/* A complete compressed frame can straddle cache windows. */
				d->cache_size = 0;
				continue;
			}
			if (result || !f.output_used || f.input_used > f.input_size)
				return -1;
			d->offset += f.input_used;
			d->pcm_pos = 0;
			d->pcm_count = f.output_used;
		}
		while (n < count && d->pcm_pos < d->pcm_count && d->frame < d->frames) {
			out[n++] = (int32_t)d->pcm[d->pcm_pos++] + 32768;
			d->frame++;
		}
	}
	return n;
}
int cgd1_audio_decode(struct cgd1_audio_decoder *d, uint8_t *out, unsigned count)
{
	uint16_t sample;
	unsigned n = 0;
	while (n < count) {
		int result = cgd1_audio_decode16(d, &sample, 1);
		if (result < 0)
			return -1;
		if (!result)
			break;
		out[n++] = sample >> 8;
	}
	return n;
}

/* Live input uses the same decoder state and implementations as flash audio.
 * No file scan, rewind, flash access or allocation occurs here. */
int cgd1_audio_stream_init(struct cgd1_audio_decoder *d, unsigned codec, uint32_t rate)
{
	if (codec >= 32 || !(CGD1_CODEC_MASK & (1ul << codec)) || codec == AUDIO_AMR || rate != 16000)
		return -1;
	memset(d, 0, sizeof(*d));
	d->codec = codec;
	d->rate = rate;
	return cgd1_audio_rewind(d);
}
int cgd1_audio_stream_decode(struct cgd1_audio_decoder *d, const uint8_t *input,
	unsigned size, unsigned *used, int16_t *output, unsigned capacity)
{
	struct decoder_frame f;
	memset(&f, 0, sizeof(f));
	f.codec = d->codec;
	f.rate = d->rate;
	f.channels = 1;
	f.state = d->state;
	f.flags = DECODER_LEGACY_IMA;
	f.input = input;
	f.input_size = size;
	f.output = output;
	f.output_size = capacity;
	int result = decode_frame(&f);
	*used = f.input_used;
	if (result == -2)
		return 0;
	if (result || f.rate != d->rate || f.input_used > size || f.output_used > capacity)
		return -1;
	return f.output_used;
}
