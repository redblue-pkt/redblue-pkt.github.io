#include "cgd1.h"

#define FLASH_CAPACITY (d->flash_capacity)

static int spi(struct cgd1 *d, const uint8_t *tx, size_t tx_size,
	uint8_t *rx, size_t rx_size)
{
	if (!d->hal.spi)
		return -1;
	return d->hal.spi(d->hal.context, tx, tx_size, rx, rx_size);
}

static int ready(struct cgd1 *d, uint32_t timeout_ms)
{
	uint8_t command = 0x05;
	uint8_t status;
	uint32_t i;

	if (!d->hal.delay_us)
		return -1;
	for (i = 0; i <= timeout_ms; i++) {
		if (spi(d, &command, 1, &status, 1))
			return -1;
		if (!(status & 1))
			return 0;
		d->hal.delay_us(d->hal.context, 1000);
	}
	return -1;
}

static int write_enable(struct cgd1 *d)
{
	uint8_t command = 0x06;
	uint8_t status;

	if (spi(d, &command, 1, NULL, 0))
		return -1;
	command = 0x05;
	if (spi(d, &command, 1, &status, 1))
		return -1;
	return status & 2 ? 0 : -1;
}

static void address_command(uint8_t out[4], uint8_t command, uint32_t address)
{
	out[0] = command;
	out[1] = address >> 16;
	out[2] = address >> 8;
	out[3] = address;
}

int cgd1_flash_id(struct cgd1 *d, uint8_t id[3])
{
	uint8_t command = 0xab;

	if (!id || !d->hal.delay_us)
		return -1;
	/* A short power interruption can reset the MCU without discharging NOR.
	 * Release deep power-down before asking for its JEDEC identification. */
	if (spi(d, &command, 1, NULL, 0))
		return -1;
	d->hal.delay_us(d->hal.context, 100);
	command = 0x9f;
	return spi(d, &command, 1, id, 3);
}

int cgd1_flash_read(struct cgd1 *d, uint32_t address, uint8_t *out, size_t size)
{
	uint8_t command[4];

	if (!out || address >= FLASH_CAPACITY || size > FLASH_CAPACITY - address)
		return -1;
	address_command(command, 0x03, address);
	return spi(d, command, 4, out, size);
}

int cgd1_flash_erase(struct cgd1 *d, uint32_t address)
{
	uint8_t command[4];

	if (address >= FLASH_CAPACITY || (address & 0xfff) || ready(d, 5000) ||
		write_enable(d))
		return -1;
	address_command(command, 0x20, address);
	if (spi(d, command, 4, NULL, 0))
		return -1;
	return ready(d, 5000);
}

int cgd1_flash_write(struct cgd1 *d, uint32_t address,
	const uint8_t *data, size_t size)
{
	uint8_t command[260];
	size_t chunk;
	size_t i;

	if (!data || address >= FLASH_CAPACITY || size > FLASH_CAPACITY - address)
		return -1;
	while (size) {
		chunk = 256 - (address & 255);
		if (chunk > size)
			chunk = size;
		if (ready(d, 100) || write_enable(d))
			return -1;
		address_command(command, 0x02, address);
		for (i = 0; i < chunk; i++)
			command[4 + i] = data[i];
		if (spi(d, command, chunk + 4, NULL, 0) || ready(d, 100))
			return -1;
		address += chunk;
		data += chunk;
		size -= chunk;
	}
	return 0;
}

