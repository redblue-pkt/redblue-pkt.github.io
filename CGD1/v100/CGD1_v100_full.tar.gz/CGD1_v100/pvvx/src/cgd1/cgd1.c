#include "cgd1.h"
#ifndef CGD1_TELINK
#include <string.h>
#endif
#include "cgd1_tables.h"

extern const uint8_t cgd1_digit_bits[2][16][7];
extern const uint8_t cgd1_digit_glyphs[10];

static int transfer(struct cgd1 *d, uint8_t address, const uint8_t *tx,
	size_t tx_size, uint8_t *rx, size_t rx_size)
{
	if (!d->hal.i2c)
		return -1;
	return d->hal.i2c(d->hal.context, address, tx, tx_size, rx, rx_size);
}

static void delay(struct cgd1 *d, uint32_t us)
{
	if (d->hal.delay_us)
		d->hal.delay_us(d->hal.context, us);
}

static void apply(struct cgd1 *d, const uint8_t *mask, const uint8_t *value)
{
	unsigned i;

	for (i = 0; i < 18; i++)
		d->lcd[i] = (d->lcd[i] & ~mask[i]) | value[i];
}

void cgd1_setup(struct cgd1 *d, const struct cgd1_hal *hal,
	enum cgd1_lcd_model model, enum cgd1_rtc_model rtc)
{
	memset(d, 0, sizeof(*d));
#ifdef CGD1_TELINK
	extern uint8_t display_buff[];
	extern uint8_t display_cmp_buff[];
	d->lcd = display_buff;
	d->lcd_sent = display_cmp_buff;
#endif
	d->hal = *hal;
	d->flash_capacity = 0x100000ul;
	d->model = model == CGD1_HT9B92;
	d->rtc_model = rtc == CGD1_RTC_REV2;
}

/* Factory COM/SEG packing, 0xbf1c / 0xc428. */
void cgd1_lcd_segment(struct cgd1 *d, uint8_t com, uint8_t seg, bool on)
{
	uint8_t byte;
	uint8_t bit;

	if (com > 3 || seg > 35)
		return;
	byte = seg / 2;
	bit = (seg & 1) ? 3 - com : 7 - com;
	if (on)
		d->lcd[byte] |= 1u << bit;
	else
		d->lcd[byte] &= ~(1u << bit);
}

void cgd1_lcd_digit(struct cgd1 *d, uint8_t position, uint8_t digit)
{
	unsigned i;
	uint8_t bit;
	uint8_t glyph;

	if (position >= 15 || digit >= 12)
		return;
	glyph = digit < 10 ? cgd1_digit_glyphs[digit] : 0;
	for (i = 0; i < 7; i++) {
		bit = cgd1_digit_bits[d->model][position][i];
		if (glyph & (1u << i))
			d->lcd[bit / 8] |= 1u << (bit % 8);
		else
			d->lcd[bit / 8] &= ~(1u << (bit % 8));
	}
}

int cgd1_lcd_init(struct cgd1 *d)
{
	static const uint8_t rohm[] = { 0xea, 0xbc, 0xf0, 0xfc };
	static const uint8_t holtek[] = { 0xc8 };
	static const uint8_t holtek_mode[] = { 0xbd };
	int result;

	if (d->model == CGD1_BU9792) {
		result = transfer(d, 0x3e, rohm, sizeof(rohm), NULL, 0);
	} else {
		result = transfer(d, 0x3e, holtek, sizeof(holtek), NULL, 0);
		if (!result)
			result = transfer(d, 0x3e, holtek_mode, sizeof(holtek_mode), NULL, 0);
	}
	memset(d->lcd, 0, 18);
	d->lcd_valid = false;
	if (result)
		return result;
	return cgd1_lcd_flush(d, true);
}

int cgd1_lcd_flush(struct cgd1 *d, bool force)
{
	uint8_t buffer[20];
	uint8_t update = 0xc8;
	int result;

	if (!force && d->lcd_valid && !memcmp(d->lcd, d->lcd_sent, 18))
		return 0;
	if (d->model == CGD1_BU9792) {
		buffer[0] = 0xe8;
		buffer[1] = 0;
		memcpy(buffer + 2, d->lcd, 18);
		result = transfer(d, 0x3e, buffer, 20, NULL, 0);
		if (!result)
			result = transfer(d, 0x3e, &update, 1, NULL, 0);
	} else {
		buffer[0] = 0;
		memcpy(buffer + 1, d->lcd, 18);
		result = transfer(d, 0x3e, buffer, 19, NULL, 0);
	}
	if (!result) {
		memcpy(d->lcd_sent, d->lcd, 18);
		d->lcd_valid = true;
	}
	return result;
}

int cgd1_lcd_measurement(struct cgd1 *d, int16_t temperature,
	uint16_t humidity, bool celsius)
{
	int value = temperature;
	unsigned pos;
	uint8_t empty[18] = { 0 };

	/* Inputs are tenths of Celsius and tenths of percent. */
	if (!celsius)
		value = value * 9 / 5 + 320;
	if (humidity > 999)
		return -1;
	if (temperature < -99 || temperature > 499) {
		apply(d, th_mask[d->model],
			th_error[d->model][celsius]);
		cgd1_lcd_digit(d, 12, humidity / 100);
		cgd1_lcd_digit(d, 13, humidity / 10 % 10);
		cgd1_lcd_digit(d, 14, humidity % 10);
		return 0;
	}
	apply(d, th_mask[d->model], empty);
	for (pos = 9; pos < 15; pos++)
		cgd1_lcd_digit(d, pos, 11);
	cgd1_lcd_segment(d, 0, 22, true);
	cgd1_lcd_segment(d, 0, 31, true);
	cgd1_lcd_segment(d, 0, 34, true);
	cgd1_lcd_segment(d, 0, 25, true);
	cgd1_lcd_segment(d, 0, 27, !celsius);
	cgd1_lcd_segment(d, 0, 29, celsius);
	if (value < 0) {
		cgd1_lcd_segment(d, 2, 23, true);
		value = -value;
	} else {
		cgd1_lcd_segment(d, 0, 23, value > 999);
		cgd1_lcd_digit(d, 9, value / 100 % 10);
	}
	cgd1_lcd_digit(d, 10, value / 10 % 10);
	cgd1_lcd_digit(d, 11, value % 10);
	cgd1_lcd_digit(d, 12, humidity / 100);
	cgd1_lcd_digit(d, 13, humidity / 10 % 10);
	cgd1_lcd_digit(d, 14, humidity % 10);
	return 0;
}

void cgd1_lcd_bluetooth(struct cgd1 *d, bool on)
{
	cgd1_lcd_segment(d, 0, 7, on);
}

void cgd1_lcd_battery(struct cgd1 *d, bool on)
{
	cgd1_lcd_segment(d, 0, 9, on);
}

uint8_t cgd1_crc8(const uint8_t *data, size_t size)
{
	uint8_t crc = 0xff;
	unsigned bit;
	size_t i;

	for (i = 0; i < size; i++) {
		crc ^= data[i];
		for (bit = 0; bit < 8; bit++)
			crc = (crc & 0x80) ? (crc << 1) ^ 0x31 : crc << 1;
	}
	return crc;
}

int cgd1_sensor_probe(struct cgd1 *d)
{
	static const uint8_t wake[] = { 0x35, 0x17 };
	static const uint8_t id[] = { 0xef, 0xc8 };
	static const uint8_t sleep[] = { 0xb0, 0x98 };
	uint8_t bytes[6] = { 0 };
	uint8_t command = 0x89;
	uint16_t identifier;
	int result;

	d->sensor = CGD1_SENSOR_NONE;
	result = transfer(d, 0x70, wake, 2, NULL, 0);
	if (!result) {
		delay(d, 240);
		result = transfer(d, 0x70, id, 2, NULL, 0);
		delay(d, 1000);
		if (!result)
			result = transfer(d, 0x70, NULL, 0, bytes, 3);
		transfer(d, 0x70, sleep, 2, NULL, 0);
		identifier = (uint16_t)bytes[0] << 8 | bytes[1];
		if (!result && cgd1_crc8(bytes, 2) == bytes[2] &&
			(identifier & 0x083f) == 0x0807) {
			d->sensor = CGD1_SHTC3;
			return 0;
		}
	}
	result = transfer(d, 0x44, &command, 1, NULL, 0);
	delay(d, 1000);
	if (!result)
		result = transfer(d, 0x44, NULL, 0, bytes, 6);
	if (!result && cgd1_crc8(bytes, 2) == bytes[2] &&
		cgd1_crc8(bytes + 3, 2) == bytes[5]) {
		d->sensor = CGD1_SHT4X;
		return 0;
	}
	return -1;
}

int cgd1_sensor_start(struct cgd1 *d)
{
	static const uint8_t wake[] = { 0x35, 0x17 };
	static const uint8_t measure[] = { 0x78, 0x66 };
	uint8_t command = 0xfd;
	int result;

	if (d->sensor_pending)
		return -1;
	if (d->sensor == CGD1_SHTC3) {
		result = transfer(d, 0x70, wake, 2, NULL, 0);
		delay(d, 240);
		if (!result)
			result = transfer(d, 0x70, measure, 2, NULL, 0);
	} else if (d->sensor == CGD1_SHT4X) {
		result = transfer(d, 0x44, &command, 1, NULL, 0);
	} else {
		return -1;
	}
	d->sensor_pending = !result;
	return result;
}

int cgd1_sensor_read(struct cgd1 *d, int16_t *temperature, uint16_t *humidity)
{
	static const uint8_t sleep[] = { 0xb0, 0x98 };
	uint8_t data[6];
	uint32_t raw_t;
	uint32_t raw_h;
	uint32_t denominator;
	int32_t t;
	int32_t h;
	int result;

	/* Caller waits >=13 ms for SHTC3, >=9 ms for SHT4x after start. */
	if (!d->sensor_pending || !temperature || !humidity)
		return -1;
	result = transfer(d, d->sensor == CGD1_SHTC3 ? 0x70 : 0x44,
		NULL, 0, data, 6);
	d->sensor_pending = false;
	if (d->sensor == CGD1_SHTC3)
		transfer(d, 0x70, sleep, 2, NULL, 0);
	if (result || cgd1_crc8(data, 2) != data[2] ||
		cgd1_crc8(data + 3, 2) != data[5])
		return -1;
	raw_t = (uint32_t)data[0] << 8 | data[1];
	raw_h = (uint32_t)data[3] << 8 | data[4];
	denominator = d->sensor == CGD1_SHTC3 ? 65536ul : 65535ul;
	t = -4500 + (int32_t)(17500ul * raw_t / denominator);
	if (d->sensor == CGD1_SHTC3)
		h = (int32_t)(10000ul * raw_h / denominator);
	else
		h = -600 + (int32_t)(12500ul * raw_h / 65535ul);
	if (h < 0)
		h = 0;
	if (h > 10000)
		h = 10000;
	*temperature = (int16_t)t;
	*humidity = (uint16_t)h;
	return 0;
}

static uint8_t bcd(uint8_t value)
{
	return value / 10 * 16 + value % 10;
}

static int unbcd(uint8_t value)
{
	if ((value & 15) > 9 || (value >> 4) > 9)
		return -1;
	return (value >> 4) * 10 + (value & 15);
}

static bool valid_time(const struct cgd1_time *t)
{
	static const uint8_t days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	unsigned maximum;

	if (t->year > 99 || !t->month || t->month > 12 || !t->day ||
		t->weekday > 6 || t->hour > 23 || t->minute > 59 || t->second > 59)
		return false;
	maximum = days[t->month - 1];
	if (t->month == 2 && t->year % 4 == 0)
		maximum++;
	return t->day <= maximum;
}

int cgd1_rtc_init(struct cgd1 *d)
{
	static const uint8_t init[][2] = {
		{ 0x17, 0x58 }, { 0x30, 0 }, { 0x31, 0x18 },
		{ 0x32, 0 }, { 0x1d, 4 }
	};
	uint8_t command[2] = { 0xf0, 0x2c };
	uint8_t status;
	unsigned i;

	if (!d->rtc_model) {
		if (transfer(d, 0x32, command, 1, &status, 1))
			return -1;
		if (transfer(d, 0x32, command, 2, NULL, 0))
			return -1;
		return status & 0x10 ? 1 : 0;
	}
	for (i = 0; i < sizeof(init) / sizeof(init[0]); i++) {
		if (transfer(d, 0x32, init[i], 2, NULL, 0))
			return -1;
	}
	command[0] = 0x1e;
	if (transfer(d, 0x32, command, 1, &status, 1))
		return -1;
	/* Leave VLF intact until the application supplies a valid date. */
	return status & 2 ? 1 : 0;
}

int cgd1_rtc_read(struct cgd1 *d, struct cgd1_time *t)
{
	uint8_t data[7];
	uint8_t address = d->rtc_model ? 0x10 : 0;
	struct cgd1_time result;
	int value[7];
	unsigned i;

	if (!t || transfer(d, 0x32, &address, 1, data, 7))
		return -1;
	for (i = 0; i < 7; i++) {
		value[i] = d->rtc_model && i == 3 ? data[i] : unbcd(data[i]);
		if (value[i] < 0)
			return -1;
	}
	result.second = value[0];
	result.minute = value[1];
	result.hour = value[2];
	result.weekday = value[3];
	if (d->rtc_model) {
		unsigned weekday = 0;

		if (!data[3] || (data[3] & (data[3] - 1)) || data[3] > 0x40)
			return -1;
		while ((data[3] >> weekday) != 1)
			weekday++;
		result.weekday = weekday;
	}
	result.day = value[4];
	result.month = value[5];
	result.year = value[6];
	if (!valid_time(&result))
		return -1;
	*t = result;
	return 0;
}

int cgd1_rtc_write(struct cgd1 *d, const struct cgd1_time *t)
{
	uint8_t data[8];
	uint8_t freeze[] = { 0x1f, 0x40 };
	uint8_t resume[] = { 0x1f, 0 };
	int result;

	if (!t || !valid_time(t))
		return -1;
	data[0] = d->rtc_model ? 0x10 : 0;
	data[1] = bcd(t->second);
	data[2] = bcd(t->minute);
	data[3] = bcd(t->hour);
	data[4] = d->rtc_model ? 1u << t->weekday : t->weekday;
	data[5] = bcd(t->day);
	data[6] = bcd(t->month);
	data[7] = bcd(t->year);
	if (d->rtc_model && transfer(d, 0x32, freeze, 2, NULL, 0))
		return -1;
	result = transfer(d, 0x32, data, 8, NULL, 0);
	if (d->rtc_model && transfer(d, 0x32, resume, 2, NULL, 0))
		return -1;
	return result;
}


uint16_t cgd1_settings_crc(const uint8_t *data, unsigned size, unsigned offset)
{
	uint16_t crc = 0xffff;
	for (unsigned i = 0; i < size; i++)
	{
		crc ^= i == offset || i == offset + 1 ? 0 : data[i];
		for (unsigned bit = 0; bit < 8; bit++)
		{
			crc = (crc >> 1) ^ ((crc & 1) ? 0xa001 : 0);
		}
	}
	return crc;
}

uint32_t cgd1_crc32_update(uint32_t crc, const uint8_t *data, unsigned size)
{
	while (size--)
	{
		crc ^= *data++;
		for (unsigned bit = 0; bit < 8; bit++)
		{
			crc = (crc >> 1) ^ ((0u - (crc & 1)) & 0xedb88320);
		}
	}
	return crc;
}
