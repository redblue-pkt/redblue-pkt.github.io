#ifndef CGD1_APP_H
#define CGD1_APP_H
#include <stdint.h>


struct cgd1_app_alarm {
	uint8_t enabled, hour, minute, days, snooze;
	uint32_t timestamp;
} __attribute__((packed));
struct cgd1_app_config {
	uint8_t volume, brightness, night_brightness, light_seconds;
	uint8_t language, h12, celsius, master, night_enabled;
	uint16_t night_start, night_end;
};
void cgd1_app_init(uint8_t revision);
void cgd1_app_configure(const struct cgd1_app_config *config);
void cgd1_app_time(uint32_t epoch, uint8_t ready);
void cgd1_app_measurement(int16_t temperature, uint16_t humidity, uint8_t valid);
void cgd1_app_poll(uint8_t connected, uint8_t playing);
void cgd1_app_audio_press(void);
void cgd1_app_button_irq(void);
void cgd1_app_button_poll(void);
void cgd1_app_audio_finished(void);
void cgd1_app_audio_stopped(void);
void cgd1_app_alarm_set(unsigned index, const struct cgd1_app_alarm *alarm);
void cgd1_app_alarm_get(unsigned index, struct cgd1_app_alarm *alarm);
void cgd1_app_master(uint8_t enabled);
void cgd1_app_cancel(void);
void cgd1_app_preview_light(uint8_t brightness);
void cgd1_app_copy_lcd(uint8_t *output);
void cgd1_app_second(void);
void cgd1_app_wake_light(void);
uint8_t cgd1_app_screen(void);
uint8_t cgd1_app_busy(void);
uint8_t cgd1_app_event(void);
uint32_t cgd1_app_snooze(void);
uint32_t cgd1_app_alarm_stamp(uint8_t hour, uint8_t minute);
uint8_t cgd1_app_runtime(unsigned index, uint32_t *timestamp);
uint32_t cgd1_app_next(void);
uint16_t cgd1_app_battery(uint16_t sample);
uint8_t cgd1_app_battery_low(void);
uint8_t cgd1_app_battery_level(void);
void cgd1_app_records(uint8_t settings[49], uint8_t alarms[147], uint32_t length, uint32_t crc);
uint8_t cgd1_app_brightness(void);
void cgd1_hw_preview(void);
void cgd1_hw_i2c(void);
void cgd1_hw_light(uint8_t level);
void cgd1_hw_audio(uint8_t start);
void cgd1_hw_binding(uint8_t enabled);
void cgd1_hw_disconnect(void);
void cgd1_hw_reset(uint8_t reboot);
void cgd1_hw_alarm_saved(void);
void cgd1_hw_master_saved(uint8_t enabled);
void cgd1_hw_flush(void);
uint32_t cgd1_hw_tick(void);
uint8_t cgd1_hw_button(void);
#endif
