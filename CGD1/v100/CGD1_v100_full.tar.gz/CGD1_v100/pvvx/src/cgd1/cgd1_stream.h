#ifndef CGD1_STREAM_H
#define CGD1_STREAM_H
#include <stdint.h>
#define CGD1_STREAM_CAPACITY 2048u
/* Positions are monotonically increasing bytes within a bounded session. */
struct cgd1_stream {
	uint32_t received __attribute__((aligned(4)));
	uint32_t consumed __attribute__((aligned(4)));
	uint16_t token, sequence;
	uint8_t state, error, volume, ended;
	uint8_t data[CGD1_STREAM_CAPACITY];
} __attribute__((aligned(4)));
#endif
