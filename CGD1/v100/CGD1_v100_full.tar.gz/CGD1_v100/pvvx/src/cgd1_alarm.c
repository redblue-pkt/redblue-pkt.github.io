#include "cgd1/cgd1_internal.h"

static uint32_t active_event_count(void);

uint32_t cgd1_alarm_remove_events(uint8_t slot)
{
	uint32_t changed = 0;

	for (unsigned int i = 0; i < 16; i++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[i];

		if (event->slot == slot)
		{
			event->enabled = 0;
			event->slot = 0;
			event->timestamp = 0;
			event->event_type = 0;
			changed = 1;
		}
	}
	return changed;
}
uint8_t cgd1_alarm_count_event_type1(void)
{
	uint8_t count = 0;

	for (unsigned int i = 0; i < 16; i++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[i];

		if (event->enabled == 1 && event->event_type == 1)
		{
			count++;
		}
	}
	return count;
}
uint8_t cgd1_alarm_count_event_type2(void)
{
	uint8_t count = 0;

	for (unsigned int i = 0; i < 16; i++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[i];

		if (event->enabled == 1 && event->event_type == 2)
		{
			count++;
		}
	}
	return count;
}
uint8_t cgd1_alarm_count_snoozable_ringing(void)
{
	uint8_t count = 0;

	for (unsigned int i = 0; i < 16; i++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[i];

		if (event->enabled != 1 || event->event_type != 0)
		{
			continue;
		}
		
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];

		if (slot->enabled == 1 && (slot->flags_raw & 1) != 0)
		{
			count++;
		}
	}
	return count;
}
uint32_t cgd1_alarm_clear_pending_events(void)
{
	uint32_t changed = 0;

	for (unsigned int i = 0; i < 16; i++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[i];

		if (event->enabled != 1 || (uint8_t)(event->event_type - 1) >= 2)
		{
			continue;
		}
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];

		if (slot->enabled != 1)
		{
			continue;
		}
		event->enabled = 0;
		if (slot->repeat_raw == 0)
		{
			slot->enabled = 0;
			changed = 1;
		}
	}
	return changed;
}

void cgd1_alarm_refresh_icon(void)
{
	bool has_alarm = !cgd1_state.config.alarms_all_off &&
		(cgd1_alarm_valid_slot_count(cgd1_state.alarms.slots, 1) || active_event_count());
	cgd1_lcd_set_bell(has_alarm);
}

uint32_t cgd1_alarm_expire_entries(void)
{
	uint32_t index;
	bool matching_event_seen = false;
	if (cgd1_board_uses_at8372() && cgd1_state.rtc_init_retries != 0)
	{
		return 0;
	}
	uint32_t now = cgd1_app_epoch();
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
		if (slot->repeat_raw != 0 || slot->enabled != 1 || slot->timestamp >= now)
		{
			continue;
		}
		if ((slot->flags_raw & 1) != 0)
		{
			if (active_event_count() != 0)
			{
				uint32_t event_index;
				for (event_index = 0; event_index < 16; event_index++)
				{
					volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[event_index];
					if (event->enabled == 1 && event->slot == index)
					{
						matching_event_seen = true;
					}
				}
			}
			if (matching_event_seen)
			{
				continue;
			}

		}
		slot->enabled = 0;

		cgd1_hw_alarm_saved();
		cgd1_alarm_refresh_icon();
		cgd1_hw_flush();
		return 1;
	}
	return 0;
}
uint32_t cgd1_alarm_disable_slot(int16_t slot)
{
	if (slot < 0)
	{

		return 0;
	}
	cgd1_state.alarms.slots[(uint8_t)slot].enabled = 0;
	cgd1_alarm_remove_events(slot);

	cgd1_hw_alarm_saved();
	return 1;
}

uint32_t cgd1_alarm_finish_events(char preserve_snoozable)
{
	uint32_t result = cgd1_alarm_stop_events(preserve_snoozable);
	if (active_event_count() == 0 && cgd1_state.next_mode == 0)
	{
		cgd1_ui_show_clock();
	}
	if (result != 0)
	{
		if (result == 1)
		{
			cgd1_hw_alarm_saved();
		}
		cgd1_alarm_refresh_icon();
		cgd1_alarm_expire_entries();
	}
	return 1;
}

void cgd1_alarm_switch_all_off(char persist)
{
	memset((void *)cgd1_state.alarms.events, 0, sizeof(cgd1_state.alarms.events));
	if (cgd1_ui_get_screen() != 6)
	{
		cgd1_lcd_set_bell(0);
	}
	if (cgd1_state.next_mode == 0)
	{
		cgd1_ui_show_clock();
	}
	else
	{
		cgd1_ui_show_next_alarm();
	}
	cgd1_state.config.alarms_all_off = 1;
	if (persist != 0)
	{
		cgd1_hw_master_saved(!cgd1_state.config.alarms_all_off);
	}
	cgd1_hw_flush();

}
void cgd1_alarm_switch_all_on(char persist)
{
	memset((void *)cgd1_state.alarms.events, 0, sizeof(cgd1_state.alarms.events));
	if (cgd1_state.next_mode == 0)
	{
		cgd1_ui_show_clock();
	}
	else
	{
		cgd1_ui_show_next_alarm();
	}
	cgd1_state.config.alarms_all_off = 0;
	if (persist != 0)
	{
		cgd1_hw_master_saved(!cgd1_state.config.alarms_all_off);
	}
	if (cgd1_alarm_expire_entries() == 0)
	{
		cgd1_hw_flush();
	}
	if (cgd1_alarm_valid_slot_count((struct cgd1_alarm_slot *)cgd1_state.alarms.slots, 1) == 0)
	{
		cgd1_lcd_set_bell(0);

	}
	else
	{

		cgd1_lcd_set_bell(1);
	}
}

uint32_t cgd1_alarm_find_next(struct cgd1_rtc_time *output, uint32_t epoch, uint32_t day_offset, uint8_t *found)
{
	struct cgd1_alarm_slot candidates[32];
	int32_t minutes_until[32];
	struct cgd1_calendar today;
	uint32_t count = 0;
	uint32_t index;
	day_offset &= 0xff;
	memset(minutes_until, 0, sizeof(minutes_until));
	memset(candidates, 0xff, sizeof(candidates));
	cgd1_epoch_to_calendar(epoch, &today);
	if (day_offset >= 8)
	{
		cgd1_epoch_to_calendar(0, &today);
		cgd1_calendar_to_rtc(&today, output);
		output->second = 0;
		*found = 0;
		return 0;
	}

	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
		if (slot->enabled != 1 || slot->hour >= 24 || slot->minute >= 60)
		{
			continue;
		}
		uint32_t weekday =
			cgd1_weekday_monday_one(cgd1_calendar_weekday(today.year, today.month, today.day));
		if (slot->repeat_raw == 0 || ((slot->repeat_raw >> (weekday - 1)) & 1u) != 0)
		{
			candidates[count] = *slot;
			minutes_until[count] =
				(int32_t)slot->hour * 60 + slot->minute - today.hour * 60 - today.minute;
			count++;
		}
	}
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->enabled != 1 || event->timestamp < epoch)
		{
			continue;
		}
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
		if (slot->enabled != 1)
		{

			continue;
		}
		struct cgd1_calendar scheduled;
		struct cgd1_rtc_time rtc;
		cgd1_epoch_to_calendar(event->timestamp, &scheduled);
		cgd1_calendar_to_rtc(&scheduled, &rtc);
		if (scheduled.year == today.year && scheduled.month == today.month &&
			scheduled.day == today.day)
		{
			candidates[count] = *slot;
			candidates[count].timestamp = event->timestamp;
			candidates[count].enabled = 1;
			candidates[count].hour = rtc.hour;
			candidates[count].minute = rtc.minute;
			minutes_until[count] = (event->timestamp - epoch) / 60u;
			count++;
		}
	}
	if (count != 0)
	{
		uint32_t best_index = 255;
		int32_t best_minutes = 1440;

		for (index = 0; index < count; index++)
		{
			if (minutes_until[index] > 0 && minutes_until[index] < best_minutes)
			{
				best_minutes = minutes_until[index];
				best_index = index;
			}
		}
		if ((int8_t)best_index >= 0)
		{
			cgd1_calendar_to_rtc(&today, output);
			output->second = 0;
			output->hour = candidates[best_index].hour;
			output->minute = candidates[best_index].minute;

			*found = 1;
			return 1;
		}
	}
	cgd1_epoch_to_calendar(epoch + 86400u, &today);
	today.hour = 0;
	today.minute = 0;
	today.second = 0;
	uint32_t tomorrow = cgd1_calendar_to_epoch(&today);
	if (cgd1_alarm_find_next(output, tomorrow, (day_offset + 1) & 0xff, found) != 0)
	{
		return 1;
	}
	if (*found == 0)
	{
		cgd1_epoch_to_calendar(day_offset == 0 ? epoch : 0, &today);
		cgd1_calendar_to_rtc(&today, output);
		output->second = 0;
		*found = 0;
	}
	return 0;
}

bool cgd1_alarm_get_next(uint8_t *output, uint32_t epoch, uint32_t day_offset)
{
	uint8_t found = 0;
	cgd1_alarm_find_next((struct cgd1_rtc_time *)output, epoch, day_offset & 0xff, &found);
	return found != 0;
}

void cgd1_alarm_show_next(char mode)
{
	uint8_t requested = (uint8_t)mode;
	uint8_t previous = cgd1_state.next_mode;
	uint32_t now;

	if (requested == previous)
	{
		if (cgd1_state.next_valid != 0)
		{
			cgd1_lcd_show_datetime(*(&cgd1_state.next_alarm), cgd1_state.config.chinese_language, cgd1_state.config.hour_system_24);
			cgd1_ui_show_next_alarm();
		}
		return;
	}
	if (requested == 1 && previous == 0)
	{
		cgd1_state.next_valid = previous;
		memset((&cgd1_state.next_alarm), 0, sizeof(*(&cgd1_state.next_alarm)));
	}
	else if (requested == 0 && previous == 1)
	{
		cgd1_lcd_colon_blink_enable();
	}
	cgd1_state.next_mode = requested;

	if (requested == 0)
	{
		if (cgd1_alarm_count_event_type1() == 0)
		{
			cgd1_ui_show_clock();
		}
		else
		{
			cgd1_ui_show_snooze_wait();
		}
		cgd1_display_flush();
		return;
	}
	now = cgd1_app_epoch();
	if (cgd1_alarm_get_next((uint8_t *)(&cgd1_state.next_alarm), now, 0))
	{
		cgd1_lcd_colon_blink_disable();

		cgd1_state.next_valid = 1;
	}
	else
	{

		cgd1_state.next_valid = 0;
	}
}

static uint32_t active_event_count(void)
{
	uint32_t index;
	uint32_t count = 0;
	for (index = 0; index < 16; index++)
	{
		count += cgd1_state.alarms.events[index].enabled == 1;
	}
	return count;
}

uint32_t cgd1_alarm_add_event(char slot, uint8_t event_type)
{
	uint32_t index;
	uint32_t free_index = 255;
	uint32_t selected = 255;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->enabled != 1)
		{
			free_index = index;
		}
		if (event->slot == (uint8_t)slot)
		{
			selected = index;
			break;
		}
	}
	if (selected == 255)
	{
		selected = free_index;
	}
	volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[selected];
	event->slot = slot;
	event->event_type = event_type;
	event->enabled = 1;
	event->timestamp = 0;
	return 0;
}

uint8_t cgd1_alarm_valid_slot_count(struct cgd1_alarm_slot *filter_slots, uint8_t enabled_only)
{
	uint32_t index;
	uint8_t count = 0;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
		if (slot->enabled != 255 && slot->hour < 24 && slot->minute < 60 &&
			(enabled_only == 0 || filter_slots[index].enabled == 1))
		{
			count++;
		}
	}
	return count;
}

void cgd1_alarm_evaluate_minute(struct cgd1_rtc_time *now)
{
	uint32_t index;
	uint32_t eligible = 0;
	if (cgd1_ui_get_screen() == 6)
	{
		return;
	}
	if (cgd1_board_uses_at8372())
	{
		if (cgd1_state.rtc_init_retries == 1)
		{
			cgd1_alarm_expire_entries();
		}
		else if (cgd1_state.rtc_init_retries > 1)
		{
			return;
		}
	}
	if (cgd1_state.minute == now->minute)
	{
		if (cgd1_state.minute_repeated != 0)
		{
			return;
		}
	}
	else
	{
		cgd1_state.minute_repeated = 0;
		cgd1_state.minute = now->minute;
	}
	if (cgd1_state.config.alarms_all_off != 0 ||
		(cgd1_alarm_valid_slot_count((struct cgd1_alarm_slot *)cgd1_state.alarms.slots, 1) == 0 &&
		 active_event_count() == 0))
	{
		cgd1_lcd_set_bell(0);
		return;
	}
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
		if (slot->enabled != 1 || slot->hour >= 24 || slot->minute >= 60)
		{
			continue;
		}
		eligible++;
		uint32_t weekday = cgd1_weekday_monday_one(now->weekday);
		if (slot->repeat_raw != 0 && ((slot->repeat_raw >> (weekday - 1)) & 1u) == 0)
		{
			continue;
		}
		if (slot->hour != now->hour || slot->minute != now->minute)
		{
			continue;
		}
		if (slot->repeat_raw != 0)
		{
			slot->timestamp = cgd1_app_epoch();
		}
		bool may_start = (slot->flags_raw & 1) != 0 || (cgd1_alarm_count_snoozable_ringing() == 0 &&
														cgd1_alarm_count_event_type2() == 0);
		if (!may_start)
		{
			if (slot->repeat_raw == 0)
			{
				cgd1_alarm_disable_slot(index);
			}
			continue;
		}
		cgd1_alarm_add_event(index, CGD1_ALARM_RINGING);
		bool snoozable_active =
			cgd1_alarm_count_snoozable_ringing() != 0 || cgd1_alarm_count_event_type2() != 0;
		cgd1_on_alarm_triggered(index, snoozable_active);
	}
	if (active_event_count() != 0)
	{
		for (index = 0; index < 16; index++)
		{
			volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
			if (event->enabled != 1 || event->event_type != CGD1_ALARM_SNOOZED)
			{
				continue;
			}
			eligible++;
			struct cgd1_calendar scheduled;
			cgd1_epoch_to_calendar(event->timestamp, &scheduled);
			if (now->hour == scheduled.hour && now->minute == scheduled.minute)
			{
				uint32_t candidate;
				for (candidate = 0; candidate < 16; candidate++)
				{
					if (cgd1_state.alarms.events[candidate].slot == event->slot)
					{
						cgd1_state.alarms.events[candidate].event_type = CGD1_ALARM_RINGING_AFTER_SNOOZE;
						break;
					}
				}
				cgd1_on_alarm_triggered(event->slot, 0);
			}
		}
	}
	cgd1_lcd_set_bell(eligible != 0);
}

void cgd1_alarm_clear_ringing_events(void)
{
	uint32_t index;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->event_type == CGD1_ALARM_RINGING ||
			event->event_type == CGD1_ALARM_RINGING_AFTER_SNOOZE)
		{
			event->enabled = 0;
		}
	}
}
static bool snooze_event(volatile struct cgd1_alarm_event *event)
{
	volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
	if (event->timestamp == 0)
	{
		event->timestamp = slot->timestamp;
		if (event->timestamp == 0)
		{

			return false;
		}
	}

	event->timestamp += 600;
	event->event_type = CGD1_ALARM_SNOOZED;
	cgd1_ui_show_snooze_wait();
	return true;
}

void cgd1_alarm_snooze(int16_t selection)
{
	uint32_t index;
	if (cgd1_state.config.alarms_all_off != 0)
	{

		return;
	}
	if (selection < 0)
	{
		for (index = 0; index < 16; index++)
		{
			volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
			volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
			if (event->enabled == 1 && (slot->flags_raw & 1) != 0 && slot->enabled == 1)
			{
				snooze_event(event);
			}
		}
		return;
	}
	if (cgd1_state.alarms.events[(uint32_t)selection].enabled != 1)
	{

		return;
	}
	uint8_t slot_index = (uint8_t)selection;
	if ((cgd1_state.alarms.slots[slot_index].flags_raw & 1) == 0)
	{

		return;
	}
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->slot == slot_index && event->enabled == 1)
		{
			snooze_event(event);
			return;
		}
	}

}

uint32_t cgd1_alarm_stop_non_snoozable(void)
{
	uint32_t index;
	uint32_t changed = 0;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->enabled != 1 || event->event_type != CGD1_ALARM_RINGING)
		{
			continue;
		}
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
		if (slot->enabled == 1 && (slot->flags_raw & 1) == 0)
		{
			event->enabled = 0;
			if (slot->repeat_raw == 0)
			{
				slot->enabled = 0;
				changed = 1;
			}
		}
	}
	return changed;
}

uint32_t cgd1_alarm_stop_events(char preserve_snoozable)
{
	uint32_t index;
	uint32_t result = 0;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->enabled != 1 || (event->event_type != 0 && event->event_type != 2))
		{
			continue;
		}
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
		if (slot->enabled != 1 || (preserve_snoozable != 0 && (slot->flags_raw & 1) != 0))
		{
			continue;
		}
		event->enabled = 0;
		if (slot->repeat_raw == 0)
		{
			slot->enabled = 0;
			result = 1;
		}
		else
		{
			result = 2;
		}
	}
	return result;
}

uint32_t cgd1_alarm_disable_active_slots(char non_snoozable_only)
{
	uint32_t index;
	uint32_t changed = 0;
	for (index = 0; index < 16; index++)
	{
		volatile struct cgd1_alarm_event *event = &cgd1_state.alarms.events[index];
		if (event->enabled != 1)
		{
			continue;
		}
		volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[event->slot];
		if (slot->enabled != 1)
		{
			continue;
		}
		if (non_snoozable_only != 0)
		{
			if ((slot->flags_raw & 1) != 0 || slot->repeat_raw != 0)
			{
				continue;
			}
		}
		else if (slot->repeat_raw != 0)
		{
			if ((slot->flags_raw & 1) != 0)
			{

				event->enabled = 0;
			}
			continue;
		}
		event->enabled = 0;
		slot->enabled = 0;
		changed = 1;
	}
	return changed;
}

