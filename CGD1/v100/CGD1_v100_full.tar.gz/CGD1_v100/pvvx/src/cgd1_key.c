#include "cgd1/cgd1_internal.h"

void cgd1_on_audio_started(void)

{
	cgd1_ble_stop_advertising();
	return;
}

void cgd1_on_audio_finished(void)

{

	cgd1_ble_set_binding_mode('\0');
	return;
}

void cgd1_key_stop(void)

{
	char mode;
	uint8_t waiting;

	mode = cgd1_audio_is_playing();
	if (mode == '\x01')
	{
		cgd1_sound_stop();
		mode = cgd1_ble_get_binding_mode();
	}
	else
	{
		mode = cgd1_ble_get_binding_mode();
	}
	if (mode == '\x01')
	{
		cgd1_lcd_cancel_alarm_blink();
		cgd1_ble_set_binding_mode('\0');
	}
	cgd1_lcd_stop_label('\0', '\x03');
	mode = cgd1_ui_get_screen();
	if (mode == '\x02')
	{
		cgd1_alarm_finish_events('\x01');
		cgd1_alarm_clear_ringing_events();
		cgd1_alarm_snooze(-1);
		if (cgd1_state.next_mode == '\0')
		{
			waiting = cgd1_alarm_count_event_type1();
			if (waiting == '\0')
			{
				cgd1_ui_show_clock();
			}
			else
			{
				cgd1_ui_show_snooze_wait();
			}
		}
		else
		{
			cgd1_ui_show_next_alarm();
		}
	}
	return;
}

void cgd1_on_short_press(void)

{
	char screen;
	uint8_t waiting;
	int changed;
	uint32_t expired;

	screen = cgd1_ui_get_screen();
	if (screen == '\x03')
	{
		cgd1_alarm_snooze(-1);
		changed = cgd1_alarm_stop_non_snoozable();
		if (changed == 0)
		{

		}
		else
		{
			cgd1_hw_alarm_saved();
			cgd1_alarm_refresh_icon();
			expired = cgd1_alarm_expire_entries();
			cgd1_hw_flush();
		}
		if (cgd1_state.next_mode == '\0')
		{
			waiting = cgd1_alarm_count_event_type1();
			if (waiting == '\0')
			{
				cgd1_ui_show_clock();
			}
			else
			{
				cgd1_ui_show_snooze_wait();
			}
		}
		else
		{
			cgd1_ui_show_next_alarm();
		}
	}

	if (cgd1_state.alarm_active == '\0')
	{

	}
	else
	{
		cgd1_state.alarm_active = '\0';
	}
	return;
}

void cgd1_key_cancel(char wake_light)
{
	if (wake_light)
	{
		cgd1_led_turn_on(0, cgd1_led_get_brightness());
	}
	cgd1_ui_show_clock();
	bool pending = cgd1_state.alarm_active || cgd1_alarm_count_event_type2() ||
		cgd1_alarm_count_event_type1();
	if (pending) {
		uint32_t changed = cgd1_alarm_disable_active_slots(0);
		if (!cgd1_state.alarm_active)
			cgd1_ui_show_clock();
		if (changed) {
			cgd1_hw_alarm_saved();
			cgd1_alarm_refresh_icon();
			cgd1_alarm_expire_entries();
			cgd1_hw_flush();
		}
	}
	cgd1_state.alarm_active = 0;
}

void cgd1_on_hold_2_seconds(void)

{
	char binding;
	uint8_t waiting;

	if (cgd1_state.alarm_active == '\0')
	{
		binding = cgd1_ble_get_binding_mode();
	}
	else
	{
		waiting = cgd1_alarm_count_event_type2();
		if ((waiting == '\0') && (waiting = cgd1_alarm_count_event_type1(), waiting == '\0'))
		{
			cgd1_alarm_finish_events('\x01');
		}
		else
		{
			cgd1_alarm_finish_events('\x01');
			cgd1_alarm_clear_pending_events();
			cgd1_ui_show_clock();
			cgd1_hw_alarm_saved();
			cgd1_alarm_refresh_icon();
			cgd1_alarm_expire_entries();
		}
		cgd1_state.alarm_active = '\0';
		binding = cgd1_ble_get_binding_mode();
	}
	if (binding == '\0')
	{
		if (controller_state == '\b')
		{
			cgd1_disconnect(0x13);
			cgd1_ble_enqueue_deferred_callback(cgd1_binding_begin_with_blink);
		}
		else
		{
			cgd1_binding_begin_with_blink();
		}
	}
	else
	{
		binding = cgd1_ble_get_binding_mode();
		if (binding != '\0')
		{

		}
	}
	return;
}

void cgd1_on_hold_6_seconds(void)

{
	uint8_t enabled;

	cgd1_alarm_expire_entries();
	enabled = cgd1_alarm_valid_slot_count(cgd1_state.alarms.slots, 1);
	if (enabled != 0)
	{
		if (cgd1_state.config.alarms_all_off == 0)
		{
			cgd1_alarm_switch_all_off('\x01');
		}
		else
		{
			cgd1_alarm_switch_all_on('\x01');
		}
	}
	return;
}

void cgd1_on_press_sequence_finished(void)

{
	char screen;

	screen = cgd1_ui_get_screen();
	if (screen == '\x06')
	{
		cgd1_binding_clear_and_reboot();
	}
	return;
}

void cgd1_on_factory_reset(void)

{
	if (cgd1_state.inhibited == '\0')
	{
		if (controller_state == '\b')
		{
			cgd1_disconnect(0x13);
		}
		cgd1_ble_stop_advertising();
		cgd1_ui_show_all_segments_locked();
		cgd1_user_data_reset();
	}
	return;
}

void cgd1_on_alarm_triggered(uint32_t slot, char resumed)

{
	uint32_t index;

	index = slot & 0xff;

	if (cgd1_state.alarms.slots[index].enabled == '\x01')
	{
		if ((resumed == '\0') && ((cgd1_state.alarms.slots[index].flags_raw & 1) == 0))
		{
			cgd1_ui_show_non_snoozable_alarm();
		}
		else
		{
			cgd1_ui_show_snoozable_alarm();
		}
	}
	if (controller_state == '\b')
	{
		cgd1_disconnect(0x13);
		cgd1_ble_enqueue_deferred_callback(cgd1_alarm_start_sound_and_light);
	}
	else
	{
		cgd1_alarm_start_sound_and_light();
	}
	return;
}

void cgd1_on_alarm_finished(void)

{
	uint8_t waiting;

	if (cgd1_state.alarm_active != '\0')
	{
		cgd1_alarm_finish_events('\0');

		cgd1_state.alarm_active = '\0';
	}
	waiting = cgd1_alarm_count_event_type1();
	if (waiting == '\0')
	{
		cgd1_ui_show_clock();
	}
	else
	{
		cgd1_ui_show_snooze_wait();
	}
	return;
}

void cgd1_on_ble_connected(void)

{

	cgd1_lcd_activity_blink_start();
	return;
}

void cgd1_binding_end(void)

{
	cgd1_ble_set_binding_mode('\0');
	cgd1_state.binding_complete = 0;
	return;
}

uint32_t cgd1_button_update_state(uint8_t level)
{
	struct cgd1_button_state *button = &cgd1_state.button;
	button->level = level;
	if (!level) {
		if (button->previous_level == 1) {
			cgd1_led_turn_on(0, cgd1_led_get_brightness());
			if (!button->first_press_seen) {
				button->first_press_seen = 1;
				button->press_count = 1;
				cgd1_key_first_press();
			} else if (button->released_ticks < 50) {
				button->press_count++;
			}
			button->pressed_ticks = 0;
		}
	} else if (!button->previous_level && level == 1) {
		button->released_ticks = 0;
	}
	if (button->counted_presses + 1 < button->press_count) {
		button->counted_presses = button->press_count;
		cgd1_key_double_press();
		if (button->counted_presses > 1)
			button->multi_press_seen = 1;
	}
	if (button->level == 1 && button->released_ticks > 50 && button->press_count == 1) {
		button->short_press_seen = 1;
		cgd1_on_short_press();
	}
	bool released_hold = false;
	if ((uint32_t)(button->pressed_ticks - 61) < 205) {
		if (!button->hold_2_seconds_seen) {
			cgd1_on_hold_2_seconds();
			button->hold_2_seconds_seen = 1;
		}
		if (button->level == 1) {
			button->short_press_seen = 1;
			released_hold = true;
		}
	}
	if (released_hold || button->level == 1) {
		if (cgd1_state.next_mode)
			cgd1_alarm_show_next(0);
	} else if (!button->level && button->pressed_ticks >= 34 && button->pressed_ticks <= 65) {
		if (!cgd1_state.config.alarms_all_off && cgd1_rtc_initialization_ready())
			cgd1_alarm_show_next(1);
	} else if (button->pressed_ticks >= 201 && cgd1_state.config.alarms_all_off == 1) {
		if (cgd1_state.next_mode)
			cgd1_alarm_show_next(0);
	}
	if (!button->level && button->pressed_ticks > 199) {
		if (!button->hold_6_seconds_seen) {
			button->hold_6_seconds_seen = 1;
			cgd1_on_hold_6_seconds();
			if (!cgd1_state.config.alarms_all_off)
				cgd1_alarm_show_next(1);
		}
		if (!button->level && button->pressed_ticks >= 666 && !button->hold_20_seconds_seen) {
			button->hold_20_seconds_seen = 1;
			if (!button->short_press_seen) {
				button->short_press_seen = 1;
				cgd1_on_factory_reset();
			}
		}
	}
	if (button->level == 1 && (button->short_press_seen || button->hold_6_seconds_seen ||
		button->hold_20_seconds_seen || button->released_ticks >= 57)) {
		cgd1_on_press_sequence_finished();
		button->scanning = 0;
		button->first_press_seen = 0;
		button->counted_presses = 0;
		button->press_count = 0;
		button->short_press_seen = 0;
		button->hold_20_seconds_seen = 0;
		button->hold_6_seconds_seen = 0;
		button->hold_2_seconds_seen = 0;
		button->multi_press_seen = 0;
		button->pressed_ticks = 0;
		button->released_ticks = 0;
		button->scan_pending = 0;
		button->wakeup_pending = 0;
		cgd1_power_unlock(5);
		cgd1_key_irq_rearm();
		return 255;
	}
	if (!button->level)
		button->pressed_ticks++;
	else
		button->released_ticks++;
	button->previous_level = button->level;
	return 0;
}

void cgd1_button_debounce_poll(void)

{
	uint8_t pins;

	if (cgd1_state.button.scanning != '\0')
	{
		pins = (cgd1_hw_button() ? 2 : 0);
		cgd1_state.button.sampled_level = pins & 2;
		if ((pins & 2) == 0)
		{
			if (cgd1_state.button.previous_sample == 0)
			{
				cgd1_button_update_state('\0');
				cgd1_state.button.previous_sample = cgd1_state.button.sampled_level;
			}
			else
			{
				cgd1_state.button.previous_sample = 0;
			}
		}
		else
		{
			cgd1_state.button.sampled_level = 1;
			if (cgd1_state.button.previous_sample == 1)
			{
				cgd1_button_update_state('\x01');
				cgd1_state.button.previous_sample = cgd1_state.button.sampled_level;
			}
			else
			{
				cgd1_state.button.previous_sample = 1;
			}
		}
	}
	return;
}

void cgd1_button_wakeup_irq(char forced)

{
	uint8_t pins;
	int pending;

	pending = cgd1_hw_irq_source();
	if ((((pending << 0xd < 0) || (forced != '\0')) &&
		 (cgd1_key_irq_mask(), cgd1_state.inhibited == '\0')) &&
		(cgd1_state.shutdown == '\0'))
	{
		pins = 0;
		cgd1_key_irq_mask();
		if (forced != '\0')
		{
			cgd1_i2c_initialize();
		}
		cgd1_state.button.wakeup_pending = 1;
	}
	return;
}

void cgd1_button_begin_scan(void)

{
	cgd1_state.button.wakeup_pending = 0;
	cgd1_power_lock(5);
	cgd1_state.button.scanning = 1;
	cgd1_state.button.previous_level = 1;
	cgd1_state.button.counted_presses = 0;
	cgd1_button_update_state('\0');
	cgd1_state.button.scan_pending = 1;
	cgd1_state.button.short_press_seen = 0;
	cgd1_state.button.hold_2_seconds_seen = 0;
	cgd1_state.button.multi_press_seen = 0;
	cgd1_state.button.scan_timestamp = cgd1_hw_tick();
	return;
}

void cgd1_button_scan_task(void)

{
	int tick;

	tick = cgd1_hw_tick();
	if (480000 < (uint32_t)(tick - cgd1_state.button.scan_timestamp))
	{
		cgd1_state.button.scan_timestamp = cgd1_hw_tick();
		cgd1_button_debounce_poll();
	}
	return;
}

