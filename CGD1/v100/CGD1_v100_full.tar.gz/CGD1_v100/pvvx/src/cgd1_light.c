#include "cgd1/cgd1_internal.h"

uint8_t cgd1_led_get_brightness(void)
{
	unsigned now = cgd1_state.time.hour * 60 + cgd1_state.time.minute;
	unsigned start = cgd1_state.config.night_start_hour * 60 + cgd1_state.config.night_start_minute;
	unsigned end = cgd1_state.config.night_end_hour * 60 + cgd1_state.config.night_end_minute;
	bool night = start == end || (start < end ? now >= start && now < end : now >= start || now < end);
	uint8_t level = night ? cgd1_state.config.led_brightness & 15 : cgd1_state.config.led_brightness >> 4;
	return level > 10 ? 10 : level;
}

uint32_t cgd1_led_timeout_callback(void)
{
	if (cgd1_state.light_ticks)
	{
		cgd1_state.light_ticks--;
		if (cgd1_state.light_ticks)
		{
			return 0;
		}
	}
	if (cgd1_state.light_requested == 2 || cgd1_state.inhibited)
	{
		return (uint32_t)-1;
	}
	cgd1_hw_light(0);
	cgd1_state.light_requested = 0;
	cgd1_power_unlock(2);
	return (uint32_t)-1;
}
void cgd1_led_turn_on(char seconds_override, uint32_t brightness)
{
	brightness &= 255;
	if (!brightness || (!seconds_override && !cgd1_state.config.led_on_time))
	{
		return;
	}
	cgd1_state.light_requested = 1;
	/* Every activation applies its level and restarts the complete duration. */
	cgd1_state.light_ticks = seconds_override ? (uint8_t)seconds_override : cgd1_state.config.led_on_time;
	cgd1_power_lock(2);
	cgd1_hw_light(brightness <= 10 ? brightness : 0);
	cgd1_soft_timer_add(cgd1_led_timeout_callback, 1000000);
}
void cgd1_led_turn_off(void)
{
	cgd1_state.light_ticks = 0;
	cgd1_state.light_requested = 0;
	cgd1_soft_timer_remove_callback(cgd1_led_timeout_callback);
	cgd1_hw_light(0);
	cgd1_power_unlock(2);
}
void cgd1_app_preview_light(uint8_t level)
{
	if (level > 10)
	{
		return;
	}
	if (!level || !cgd1_state.config.led_on_time)
	{
		cgd1_led_turn_off();
		return;
	}
	/* Slider preview follows the same configured duration as the foot. */
	cgd1_led_turn_on(0, level);
}
