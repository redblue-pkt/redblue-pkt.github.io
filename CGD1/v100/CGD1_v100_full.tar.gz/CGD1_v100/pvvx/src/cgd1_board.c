/* CGD1 integration. Hardware evidence and protocol: docs/CGD1.md. */
#ifdef CGD1_HOST_TEST
#include "../tests/cgd1_mock.h"
#else
#include "tl_common.h"
#include "app_config.h"
#include "drivers.h"
#include "stack/ble/ble.h"
#include "app.h"
#include "ble.h"
#include "lcd.h"
#include "rtc.h"
#include "i2c.h"
#include "flash_eep.h"
#endif
#if DEVICE_TYPE == DEVICE_CGD1
#include "cgd1/cgd1.h"
#include "cgd1/cgd1_audio.h"
#include "cgd1/cgd1_stream.h"
#include "cgd1/cgd1_beep.h"
#include "cgd1/cgd1_app.h"
#include "cgd1_board.h"

#define CFG_ID 0x60
#define ALARM_ID 0x70
#define RING_SIZE 4096
#define NOR_TIMEOUT_US 3000000
#define CGD1_AUDIO_PWM_PERIOD (CLOCK_SYS_CLOCK_HZ / 16000)

/* Factory records occupy SPI sectors 0..0x5fff. PVVX transport metadata
 * remains in emulated EEPROM; both audio slots follow the reserved sectors. */
struct settings {
	u8 version, brightness, volume, language;
	s16 time_reserved; /* Zero: time follows the native PVVX local-time convention. */
	u8 slot, reserved;
	u32 length, crc;
};
struct alarm {
	u8 enabled, hour, minute, days, snooze;
	u32 once_at; /* Persistent calendar occurrence; original record also stores this. */
};
static void alarm_import(unsigned index, const struct alarm *stored)
{
	struct cgd1_app_alarm a;
	a.enabled = stored->enabled;
	a.hour = stored->hour;
	a.minute = stored->minute;
	a.days = stored->days;
	a.snooze = !!stored->snooze;
	a.timestamp = stored->once_at;
	cgd1_app_alarm_set(index, &a);
}

static void alarm_export(unsigned index, struct alarm *stored)
{
	struct cgd1_app_alarm a;
	cgd1_app_alarm_get(index, &a);
	memset(stored, 0, sizeof(*stored));
	stored->enabled = a.enabled;
	stored->hour = a.hour;
	stored->minute = a.minute;
	stored->days = a.days;
	stored->snooze = a.snooze ? 10 : 0;
	stored->once_at = a.timestamp;
}

static void settings_store(void);
static void settings_load(void);
static int cgd1_storage_migrate(void);
static u8 settings_ready, settings_loaded, migration_pending;
static struct settings settings;
struct ringtone_slot {
	u32 length, crc;
};
static struct ringtone_slot ringtone_slots[2];
static int save_slots(void)
{
	return flash_write_cfg(ringtone_slots, 0x68, sizeof(ringtone_slots)) == sizeof(ringtone_slots) ? 0 : -1;
}

static struct cgd1 board;
static u8 initialized, revision, rtc_valid, nor_ok, rtc_fault, cg_sensor_valid;
static u8 light_level, lcd_error, last_i2c_address, last_i2c_error;
static u8 ringing, last_button;
static u32 snooze_at, last_second;
static u32 ring_tick, ring_seconds;
static u32 last_alarm_minute = 0xffffffff;
static u32 alarm_run_due[16];
static u8 alarm_run_state[16], alarm_ui = 1, alarm_event;
static u16 ring[RING_SIZE];
static volatile u16 ring_read, ring_write;
static volatile u8 audio_running;
static volatile u32 underruns;
static volatile u32 tone_phase;
static volatile u8 pcm_mode, audio_eof;
static u8 fast_transfer;
static volatile u8 audio_volume, beep_mode, beep_done;
static u8 alarm_blink, preview_audio;
static u8 light_seconds = 8, light_dirty, blink_on, light_pwm_fault;
static u8 settings_pending;
static u32 settings_save_tick;
static volatile u8 foot_pending, foot_audio_stop;
static u8 foot_stop_armed;
static u8 deferred_disconnect;
static u32 deferred_disconnect_tick;
static void dump_task(void);
static u32 blink_tick, audio_length, audio_cycle_base, audio_reference_cycle;
static u16 audio_neutral;
static u32 audio_gain;
static const u8 *audio_memory;
static u8 spi_jedec[3];
static u32 spi_capacity, slot_bytes, audio_base;
static struct cgd1_audio_decoder decoder;
static struct cgd1_stream stream;
static u32 stream_tick;
static void stream_service(void);
/* state: 0 idle, 1 buffering, 2 playing, 3 draining, 4 error. */
static int stream_active(void)
{
	return stream.state >= 1 && stream.state <= 3;
}
static struct {
	u16 start, end;
	u8 enabled, brightness;
} night;
/* upload: 0 idle, 1 erase, 2 receiving, 3 verify, 4 done, 5 error */
static struct {
	u8 state, slot, pending, streaming, failure, legacy_staging;
	u16 page_used;
	u8 page[256];
	u32 length, expected_crc, received, erased, verify, crc, busy_tick, activity_tick;
} upload;
static struct {
	u8 active, failed;
	u16 used, pos;
	u32 offset, crc;
	u8 data[256];
} spi_dump;
int cgd1_transfer_busy(void)
{
	return spi_dump.active || upload.pending || (upload.state >= 1 && upload.state <= 3);
}
static u32 slot_base(u8 slot);
static u32 upload_base(void)
{
	return upload.legacy_staging ? (upload.slot ? spi_capacity / 2 : 0) : slot_base(upload.slot);
}
RAM lcd_flg_t lcd_flg;
RAM u8 display_buff[LCD_BUF_SIZE], display_cmp_buff[LCD_BUF_SIZE];
RAM u8 lcd_i2c_addr;

static u32 le32(const u8 *p)
{
	return (u32)p[0] | (u32)p[1] << 8 | (u32)p[2] << 16 | (u32)p[3] << 24;
}
static void put32(u8 *p, u32 value)
{
	p[0] = value;
	p[1] = value >> 8;
	p[2] = value >> 16;
	p[3] = value >> 24;
}
static u32 slot_base(u8 slot)
{
	return 0x6000ul + (slot ? slot_bytes : 0);
}
static int hal_i2c(void *ctx, uint8_t address, const uint8_t *tx,
	size_t ntx, uint8_t *rx, size_t nrx)
{
	u8 request[35];
	i2c_utr_t *tr = (i2c_utr_t *)request;
	(void)ctx;
	if (ntx > 32 || nrx > 32)
		return -1;
	/* mode marks where the SDK issues a repeated START to the read address.
	 * A write-only transaction must never request that extra address phase. */
	tr->mode = nrx ? ntx : 0;
	tr->rdlen = nrx;
	tr->wrdata[0] = (address << 1) | (!ntx && nrx ? 1 : 0);
	if (ntx)
		memcpy(tr->wrdata + 1, tx, ntx);
	last_i2c_address = address;
	last_i2c_error = I2CBusUtr(rx, tr, ntx);
	return last_i2c_error;
}
static int spi_wait_ready(void)
{
	u32 start = clock_time();
	while (reg_spi_ctrl & FLD_SPI_BUSY) {
		if (clock_time_exceed(start, 2000))
			return -1;
	}
	return 0;
}
static int hal_spi(void *ctx, const uint8_t *tx, size_t ntx,
	uint8_t *rx, size_t nrx)
{
	size_t i;
	volatile u8 discard;
	int result = -1;
	(void)ctx;
	spi_master_gpio_set(SPI_GPIO_GROUP_B6B7D2D7);
	spi_masterCSpin_select(GPIO_PD2);
	spi_master_init(CLOCK_SYS_CLOCK_HZ / 4000000 / 2 - 1, SPI_MODE0);
	gpio_write(GPIO_PD2, 0);
	reg_spi_ctrl &= ~(FLD_SPI_RD | FLD_SPI_DATA_OUT_DIS);
	for (i = 0; i < ntx; i++) {
		reg_spi_data = tx[i];
		if (spi_wait_ready())
			goto complete;
	}
	if (nrx) {
		reg_spi_ctrl |= FLD_SPI_DATA_OUT_DIS | FLD_SPI_RD;
		discard = reg_spi_data;
		(void)discard;
		if (spi_wait_ready())
			goto complete;
		for (i = 0; i < nrx; i++) {
			rx[i] = reg_spi_data;
			if (spi_wait_ready())
				goto complete;
		}
	}
	result = 0;
complete:
	gpio_write(GPIO_PD2, 1);
	/* SPI and I2C share the controller; restore it on success AND timeout. */
	reg_rst0 = FLD_RST0_I2C;
	reg_rst0 = 0;
	init_i2c();
	return result;
}
static void hal_delay(void *ctx, uint32_t us)
{
	(void)ctx;
	sleep_us(us);
}
static int light_pwm_ready(void)
{
	return !light_pwm_fault && (reg_clk_en0 & FLD_CLK0_PWM_EN) && !reg_pwm_clk
		&& !(reg_gpio_pd_gpio & BIT(3)) && !(reg_gpio_pd_oen & BIT(3))
		&& (reg_pwm_enable & BIT(1))
		&& !(reg_pwm_invert & BIT(1))
		&& !(reg_pwm_n_invert & BIT(1))
		&& !(reg_pwm_pol & BIT(1))
		&& !(read_reg8(0x5ae) & (BIT(6) | BIT(7)));
}
static int light_wait_frame(void)
{
	/* W1C: discard stale frame completion before observing a new period. */
	reg_pwm_irq_sta = FLD_IRQ_PWM1_FRAME;
	u32 started = clock_time();
	while (!(reg_pwm_irq_sta & FLD_IRQ_PWM1_FRAME))
	{
		if (clock_time_exceed(started, 1000))
		{
			return 0;
		}
	}
	reg_pwm_irq_sta = FLD_IRQ_PWM1_FRAME;
	return 1;
}
static void light(u8 value)
{
	u8 irq = irq_disable();
	if (value > 10)
	{
		value = 10;
	}
	if (value && light_pwm_ready() && reg_pwm_max(PWM1_ID) == 1000)
	{
		/* Update the running channel's compare only. Preserve its counter,
		 * clock, enable state and PD3 mux across a nonzero level change. */
		reg_pwm_cmp(PWM1_ID) = 1000 - value * 100;
		light_level = value;
		irq_restore(irq);
		return;
	}
	if (!value)
	{
		gpio_write(GPIO_PD3, 0);
		gpio_set_func(GPIO_PD3, AS_GPIO);
		gpio_set_output_en(GPIO_PD3, 1);
		pwm_stop(PWM1_ID);
	}

	else
	{
		/* Keep the transistor off while restoring the entire PWM1 path. */
		gpio_write(GPIO_PD3, 0);
		gpio_set_func(GPIO_PD3, AS_GPIO);
		gpio_set_output_en(GPIO_PD3, 1);
		pwm_stop(PWM1_ID);
		reg_clk_en0 |= FLD_CLK0_PWM_EN;
		pwm_set_clk(CLOCK_SYS_CLOCK_HZ, CLOCK_SYS_CLOCK_HZ);
		reg_pwm_invert &= ~BIT(1);
		reg_pwm_n_invert &= ~BIT(1);
		reg_pwm_pol &= ~BIT(1);
		reg_pwm_cycle(PWM1_ID) = (1000ul << 16) | (1000 - value * 100);
		pwm_start(PWM1_ID);
		/* Keep PD3 low until TWO fresh periods complete. Never expose a
		 * stopped/starting peripheral to the backlight transistor. */
		if (!light_wait_frame() || !light_wait_frame())
		{
			pwm_stop(PWM1_ID);
			light_pwm_fault = 1;
			light_level = 0;
			irq_restore(irq);
			return;
		}
		light_pwm_fault = 0;
		gpio_set_func2(GPIO_PD3, AS_PWM1_N);
	}
	light_level = value;
	irq_restore(irq);
}

static void light_task(void)
{
	/* BLE callbacks only request an update. Apply after blt_sdk_main_loop. */
	light_dirty = 1;
}
static void light_update(void)
{
	if (alarm_blink && ringing && !preview_audio) {
		if (clock_time_exceed(blink_tick, 1000000)) {
			blink_tick += CLOCK_16M_SYS_TIMER_CLK_1S;
			blink_on ^= 1;
		}
		u8 target = blink_on ? cgd1_app_brightness() : 0;
		if (target != light_level)
			light(target);
	}
	if (light_level && (light_dirty || !light_pwm_ready()
		|| reg_pwm_cycle(PWM1_ID) != ((1000ul << 16) | (1000 - light_level * 100))))
		light(light_level);
	if (!light_level)
	{
		/* Audio may touch shared PWM registers; off stays a GPIO low. */
		light(0);
	}
	light_dirty = 0;
}
static void settings_sync(void)
{
	struct cgd1_app_config c;
	c.volume = settings.volume;
	c.brightness = settings.brightness;
	c.night_brightness = night.brightness;
	c.light_seconds = light_seconds;
	c.language = settings.language;
	c.h12 = settings.reserved & 1;
	c.celsius = !cfg.flg.temp_F_or_C;
	c.master = !(settings.reserved & 2);
	c.night_enabled = night.enabled;
	c.night_start = night.start;
	c.night_end = night.end;
	cgd1_app_configure(&c);
}
static int save_settings(void)
{
	if (light_level)
	{
		settings_pending = 1;
		settings_save_tick = clock_time();
		settings_sync();
		return 0;
	}
	int result = flash_write_cfg(&settings, CFG_ID, sizeof(settings)) == sizeof(settings) ? 0 : -1;
	if (!result) {
		settings_sync();
		settings_store();
		settings_pending = 0;
	}
	return result;
}
static void wakeup_callback(int early)
{
	(void)early;
}
static void ensure_board(void)
{
	struct cgd1_hal hal;
	unsigned i;
	if (initialized)
		return;
	initialized = 1;
	memset(&hal, 0, sizeof(hal));
	hal.i2c = hal_i2c;
	hal.spi = hal_spi;
	hal.delay_us = hal_delay;
	revision = (!!gpio_read(GPIO_PB4)) | ((!!gpio_read(GPIO_PB5)) << 1);
	cgd1_setup(&board, &hal, revision == 2 ? CGD1_HT9B92 : CGD1_BU9792,
		revision >= 2 ? CGD1_RTC_REV2 : CGD1_RTC_LEGACY);
	int settings_size = flash_read_cfg(&settings, CFG_ID, sizeof(settings));
	settings_loaded = settings_size == sizeof(settings);
	if (settings_size != sizeof(settings)
		|| (settings.version != 1 && settings.version != 2) || settings.brightness > 10 || settings.volume > 5
		|| settings.language > 3 || settings.slot > 1) {
		settings_loaded = 0;
		memset(&settings, 0, sizeof(settings));
		settings.version = 2;
		settings.brightness = 10;
		settings.volume = 5;
	}
	if (settings.version == 1) {
		/* r2 stored UTC plus a separate offset. Require a native PVVX time
		 * synchronization once, without discarding alarm or audio settings.
		 * Persist the marker so a reboot cannot accept the old UTC as local. */
		settings.version = 2;
		settings.reserved |= 0x80;
		settings.time_reserved = 0;
		save_settings();
	}
	settings.time_reserved = 0;
	if (flash_read_cfg(ringtone_slots, 0x68, sizeof(ringtone_slots)) != sizeof(ringtone_slots)) {
		memset(ringtone_slots, 0, sizeof(ringtone_slots));
		if ((settings.reserved & 0x20) && settings.length) {
			ringtone_slots[settings.slot].length = settings.length;
			ringtone_slots[settings.slot].crc = settings.crc;
			save_slots();
		}
	}
	cgd1_app_init(revision);
	for (i = 0; i < 16; i++)
	{
		struct alarm stored = {0};
		int length = flash_read_cfg(&stored, ALARM_ID + i, sizeof(stored));
		if (length == 5)
			stored.once_at = 0;
		if ((length != 5 && length != sizeof(stored))
			|| stored.enabled > 1 || stored.hour > 23 || stored.minute > 59
			|| stored.days > 127 || stored.snooze > 30)
			memset(&stored, 0, sizeof(stored));
		if (stored.snooze && stored.snooze != 10)
		{
			stored.snooze = 10;
			flash_write_cfg(&stored, ALARM_ID + i, sizeof(stored));
		}
		alarm_import(i, &stored);
	}
	pwm_set_clk(CLOCK_SYS_CLOCK_HZ, CLOCK_SYS_CLOCK_HZ);
	/* The factory button is a single active-low key on PA1. Configure it
	 * explicitly; relying on reset-state GPIO left presses floating. */
	gpio_set_func(GPIO_PA1, AS_GPIO);
	gpio_setup_up_down_resistor(GPIO_PA1, PM_PIN_PULLUP_1M);
	gpio_set_output_en(GPIO_PA1, 0);
	reg_irq_src = FLD_IRQ_GPIO_EN;
	gpio_set_interrupt(GPIO_PA1, pol_falling);
	/* Factory init 0x13360 configures PD4 as the audio amplifier enable,
	 * with a 100 kOhm pulldown so the amplifier remains muted at boot. */
	gpio_set_func(GPIO_PD4, AS_GPIO);
	gpio_setup_up_down_resistor(GPIO_PD4, PM_PIN_PULLDOWN_100K);
	gpio_set_output_en(GPIO_PD4, 1);
	gpio_write(GPIO_PD4, 0);
	light(0);
	bls_pm_registerAppWakeupLowPowerCb(wakeup_callback);
	spi_capacity = slot_bytes = 0;
	if (!cgd1_flash_id(&board, spi_jedec) && spi_jedec[0] && spi_jedec[0] != 255
		&& spi_jedec[1] && spi_jedec[1] != 255 && spi_jedec[2] >= 16 && spi_jedec[2] <= 24) {
		spi_capacity = 1ul << spi_jedec[2];
		slot_bytes = ((spi_capacity - 0x6000ul) / 2) & ~4095ul;
		board.flash_capacity = spi_capacity;
		nor_ok = 1;
	} else {
		board.flash_capacity = 0;
		nor_ok = 0;
	}
	
	if (flash_read_cfg(&night, 0x61, sizeof(night)) != sizeof(night)
		|| night.enabled > 1 || night.brightness > 10 || night.start >= 1440 || night.end >= 1440) {
		night.start = 21 * 60;
		night.end = 6 * 60;
		night.enabled = 1;
		night.brightness = 5;
	}
	if (flash_read_cfg(&light_seconds, 0x62, 1) != 1 || light_seconds > 30)
		light_seconds = 8;
	if (nor_ok) {
		settings_load();
		if (!cgd1_storage_migrate())
			settings_ready = 1;
		else if (settings.length <= slot_bytes)
			migration_pending = 1;
	}
	last_button = !gpio_read(GPIO_PA1);
	settings_sync();
	settings_store();
}

int rtc_read_all(void)
{
	struct cgd1_time t;
	if (cgd1_rtc_read(&board, &t)) {
		rtc_fault = 1;
		rtc_valid = 0;
		return -1;
	}
	rtc.year = t.year;
	rtc.month = t.month;
	rtc.days = t.day;
	rtc.weekday = t.weekday;
	rtc.hours = t.hour;
	rtc.minutes = t.minute;
	rtc.seconds = t.second;
	rtc_fault = 0;
	return 0;
}
u32 rtc_get_utime(void)
{
	if (!rtc_valid || rtc_read_all())
		return wrk.utc_time_sec;
	return rtc_to_utime(&rtc);
}
void rtc_set_utime(u32 ut)
{
	struct cgd1_time t;
	u8 clear[2], status;
	ensure_board();
	if (ut < 946684800u || ut > 4102444799u)
		return;
	/* A valid PVVX timestamp is sufficient to run schedules in RAM.
	 * A later I2C failure reports rtc_fault without vetoing this clock. */
	rtc_valid = 1;
	last_alarm_minute = 0xffffffff;
	utime_to_rtc(ut, &rtc);
	t.year = rtc.year;
	t.month = rtc.month;
	t.day = rtc.days;
	t.weekday = rtc.weekday;
	t.hour = rtc.hours;
	t.minute = rtc.minutes;
	t.second = rtc.seconds;
	if (cgd1_rtc_write(&board, &t)) {
		rtc_fault = 1;
		rtc_valid = 0;
		return;
	}
	clear[0] = board.rtc_model ? 0x1e : 0xf0;
	if (hal_i2c(0, 0x32, clear, 1, &status, 1)) {
		rtc_fault = 1;
		rtc_valid = 0;
		return;
	}
	clear[1] = status & ~(board.rtc_model ? 2 : 0x10);
	if (hal_i2c(0, 0x32, clear, 2, 0, 0)) {
		rtc_fault = 1;
		rtc_valid = 0;
		return;
	}
	if (settings.reserved & 0x80) {
		settings.reserved &= ~0x80;
		if (save_settings()) {
			settings.reserved |= 0x80;
			rtc_fault = 1;
		rtc_valid = 0;
			return;
		}
	}
	rtc_valid = 1;
	rtc_fault = 0;
	rtc_sync_utime = 0;
	last_alarm_minute = 0xffffffff;
}
void init_rtc(void)
{
	ensure_board();
	rtc_i2c_addr = 0x32 << 1;
	int status = cgd1_rtc_init(&board);
	rtc_valid = status == 0 && !(settings.reserved & 0x80);
	if (status == 1 && !(settings.reserved & 0x80)) {
		wrk.utc_time_sec = 0x5c29cc80ul + 80 * 360;
		rtc_set_utime(wrk.utc_time_sec);
	}
	if (rtc_valid && !rtc_read_all())
		wrk.utc_time_sec = rtc_to_utime(&rtc);
	else
		rtc_valid = 0;
	rtc_sync_utime = 0;
}

void init_lcd(void)
{
	ensure_board();
	lcd_error = cgd1_lcd_init(&board);
	lcd_i2c_addr = lcd_error ? 0 : 0x7c;
	memset(display_cmp_buff, 0xff, sizeof(display_cmp_buff));
	SET_LCD_UPDATE();
}
void cgd1_boot_display(void)
{
	/* Load the persisted level and RTC before the first light activation. */
	if (cfg.flg2.screen_off)
		return;
	settings_sync();
	cgd1_app_time(wrk.utc_time_sec, rtc_valid);
	lcd();
	update_lcd();
	cgd1_app_wake_light();
	light_update();
}
void reinit_lcd(void)
{
	init_lcd();
	if (cfg.flg2.screen_off) {
		memset(display_buff, 0, sizeof(display_buff));
		send_to_lcd();
	}
}
void send_to_lcd(void)
{
	if (!lcd_i2c_addr)
		init_lcd();
	if (!lcd_i2c_addr)
		return;
	lcd_error = cgd1_lcd_flush(&board, true);
	if (lcd_error) {
		/* Retry the controller setup after a failed transaction. */
		lcd_i2c_addr = 0;
		board.lcd_valid = false;
	}
}
void update_lcd(void)
{
	if (!lcd_i2c_addr || memcmp(display_buff, display_cmp_buff, 18)) {
		send_to_lcd();
		lcd_flg.b.send_notify = lcd_flg.b.notify_on;
	}
}
void lcd(void)
{
	cgd1_app_copy_lcd(board.lcd);
	if (cgd1_app_screen() != 6)
		cgd1_lcd_battery(&board, cfg.flg.show_batt_enabled || cgd1_app_battery_low());
}
void show_big_number_x10(s16 value)
{
	cgd1_lcd_measurement(&board, value, measured_data.humi_x01, !cfg.flg.temp_F_or_C);
}
void show_small_number(s16 value, bool percent)
{
	(void)percent;
	cgd1_lcd_measurement(&board, measured_data.temp_x01,
		value < 0 ? 0 : value > 99 ? 990 : value * 10, !cfg.flg.temp_F_or_C);
}
void show_ble_symbol(bool on)
{
	cgd1_lcd_bluetooth(&board, on);
}
void show_battery_symbol(bool on)
{
	cgd1_lcd_battery(&board, on);
}
/* The CGD1 has no smiley. Required by the generic PVVX diagnostics API. */
void show_smiley(u8 value) { (void)value; }
void show_temp_symbol(u8 value) { (void)value; }
void show_clock(void) { lcd(); }

static void cgd1_stop_audio(void)
{
	u8 irq = irq_disable();
	u8 was_running = audio_running;
	u8 was_playing = ringing;
	u8 was_streaming = stream_active();
	if (was_streaming)
		stream.state = 0;
	/* Mute before changing either audio pin. */
	gpio_write(GPIO_PD4, 0);
	audio_running = 0;
	timer_stop(TIMER1);
	reg_irq_mask &= ~FLD_IRQ_TMR1_EN;
	reg_tmr_sta = FLD_TMR_STA_TMR1;
	if (was_running) {
		/* Allow amplifier shutdown before forcing its input pins low.
		 * Keep BLE interrupts enabled during this one millisecond guard. */
		irq_restore(irq);
		sleep_us(1000);
		irq = irq_disable();
	}
	pwm_stop(PWM0_ID);
	pwm_stop(PWM4_ID);
	gpio_set_func(GPIO_PC1, AS_GPIO);
	gpio_set_func(GPIO_PC0, AS_GPIO);
	gpio_write(GPIO_PC1, 0);
	gpio_write(GPIO_PC0, 0);
	irq_restore(irq);
	if (was_playing && !was_streaming)
		cgd1_app_audio_stopped();
	ringing = 0;
	u8 was_blinking = alarm_blink;
	alarm_blink = 0;
	if (was_blinking)
		light(light_level);
	preview_audio = 0;
	beep_done = 0;
	light_task();
	SET_LCD_UPDATE();
}
void cgd1_prepare_sleep(void)
{
	cgd1_stop_audio();
	snooze_at = 0;
	light(0);
}
static int audio_read(void *context, uint32_t offset, uint8_t *data, unsigned count)
{
	if (audio_memory) {
		if (offset > audio_length || count > audio_length - offset)
			return -1;
		memcpy(data, audio_memory + offset, count);
		return 0;
	}
	return cgd1_flash_read(&board, *(u32 *)context + offset, data, count);
}
static int select_ringtone_slot(u8 index)
{
	struct ringtone_slot *slot = &ringtone_slots[index];
	struct cgd1_audio_decoder check;
	u32 base = slot_base(index);
	if (!slot->length || slot->length > slot_bytes
		|| cgd1_audio_open(&check, audio_read, &base, slot->length))
		return 3;
	struct settings previous = settings;
	settings.slot = index;
	settings.length = slot->length;
	settings.crc = slot->crc;
	settings.reserved = (settings.reserved & ~12) | 0x60;
	if (save_settings()) {
		settings = previous;
		return 3;
	}
	return 0;
}

static u16 audio_pwm_sample(u16 sample)
{
	/* Q12 volume/carrier scaling: preserve the 8 kHz factory level.
	 * The product fits uint32_t even at sample=65535, volume=5. */
	return ((u32)sample * audio_gain) >> 20;
}
/* Decode, SPI reads and PCM-to-duty conversion run in the main loop.
 * The ISR consumes one prepared PWM duty value per source sample. */
static uint16_t source_samples[128];
static unsigned source_pos, source_count;
static uint32_t source_phase;
static int32_t source_a, source_b;
static int audio_source_sample(void)
{
	if (source_pos == source_count)
	{
		if (decoder.frame == decoder.frames && cgd1_audio_rewind(&decoder))
		{
			return -1;
		}
		int count = cgd1_audio_decode16(&decoder, source_samples, 128);
		if (count <= 0)
		{
			return -1;
		}
		source_count = count;
		source_pos = 0;
	}
	return source_samples[source_pos++];
}
static int audio_fill(void)
{
	u16 data[128];
	u16 free = (ring_read - ring_write - 1) & (RING_SIZE - 1);
	int n;
	unsigned i;
	if (free < 128)
		return 0;
	/* Fixed 16 kHz output avoids missing high-rate timer interrupts.
	 * Keep the source clock with a rational phase accumulator. */
	n = 128;
	for (i = 0; i < (unsigned)n; i++)
	{
		while (source_phase >= 16000)
		{
			source_a = source_b;
			source_b = audio_source_sample();
			if (source_b < 0)
			{
				return -1;
			}
			source_phase -= 16000;
		}
		data[i] = source_a + (source_b - source_a) * (int32_t)source_phase / 16000;
		source_phase += decoder.rate;
		ring[(ring_write + i) & (RING_SIZE - 1)] = audio_pwm_sample(data[i]);
	}
	__asm__ volatile ("" ::: "memory");
	ring_write = (ring_write + n) & (RING_SIZE - 1);
	return 1;
}
static void audio_enable(u32 period)
{
	gpio_set_func(GPIO_PC1, AS_PWM0);
	gpio_set_func(GPIO_PC0, AS_PWM4_N);
	/* Factory 0x13360: mode=3 at 0x800783, PWM4=0x05dc0280.
	 * Factory 0x1466..0x149e restarts both channels for EVERY sample.
	 * 0x0202 in its literal pool is GPIO_PC1, not a PWM compare value. */
	/* main.c gates PWM off at boot. Register setup alone cannot run it. */
	reg_clk_en0 |= FLD_CLK0_PWM_EN;
	pwm_set_clk(CLOCK_SYS_CLOCK_HZ, CLOCK_SYS_CLOCK_HZ);
	pwm_set_mode(PWM0_ID, PWM_IR_MODE);
	pwm_set_pulse_num(PWM0_ID, 0);
	/* Factory 0x133a4..0x133b2 sets bit 0 of 0x800784.
	 * PC1 must be inverted relative to the PC0 PWM4_N reference. */
	reg_pwm_invert = (reg_pwm_invert & ~BIT(4)) | BIT(0);
	reg_pwm_n_invert &= ~BIT(4);
	pwm_set_cycle_and_duty(PWM0_ID, period, audio_neutral);
	pwm_set_cycle_and_duty(PWM4_ID, period, audio_neutral);
	/* Start both neutral waveforms while the amplifier is muted. */
	pwm_start(PWM4_ID);
	pwm_start(PWM0_ID);
	gpio_write(GPIO_PD4, 1);
	foot_stop_armed = !!gpio_read(GPIO_PA1);
	audio_running = 1;
	ringing = 1;

	timer1_set_mode(TIMER_MODE_SYSCLK, 0, CLOCK_SYS_CLOCK_HZ / (beep_mode ? 8000 : 16000));
	timer_start(TIMER1);
}
static void audio_start(u8 preview)
{
	if (migration_pending)
		return;
	unsigned i;
	u32 rate = 8000;
	u32 duration = 600; /* Factory 0xF3EC: cfg[2..3] = 0x0258. */
	cgd1_stop_audio();
	preview_audio = !!preview;
	if (preview_audio)
	{
		cgd1_app_preview_light(0);
		light(0);
	}
	ring_tick = clock_time();
	ring_seconds = 600;
	audio_eof = 0;
	beep_mode = preview == 2;
	if (upload.state == 1 || upload.state == 2 || upload.state == 3)
		return;
	if (!settings.volume) {
		ringing = 1;
		SET_LCD_UPDATE();
		return;
	}
	audio_memory = 0;
	audio_length = settings.length;
	pcm_mode = preview != 2 && nor_ok && settings.length && !upload.pending;
	if (preview != 2 && !pcm_mode)
		return;
	audio_base = (settings.reserved & 0x20) ? slot_base(settings.slot) :
		(settings.reserved & 0x40) ? (settings.slot ? spi_capacity / 2 : 0) :
		(settings.slot ? 0x33000ul : 0x1b000ul);
	if (pcm_mode) {
		if (cgd1_audio_open(&decoder, audio_read, &audio_base, audio_length))
			return;
		rate = decoder.rate;
		if (decoder.frames / rate + 1 > duration)
			duration = decoder.frames / rate + 1;
	}
	/* Decode at the source rate; render through a fixed 16 kHz timer. */
	u32 period = beep_mode ? CGD1_AUDIO_PWM_PERIOD : CLOCK_SYS_CLOCK_HZ / 32000;
	audio_volume = settings.volume;
	audio_gain = (u32)audio_volume * period * 4096 / CGD1_AUDIO_PWM_PERIOD;
	audio_cycle_base = period << 16;
	audio_neutral = audio_pwm_sample(32768);
	audio_reference_cycle = audio_cycle_base | audio_neutral;
	ring_read = ring_write = 0;
	tone_phase = 0;
	underruns = 0;
	if (pcm_mode) {
		source_pos = source_count = source_phase = 0;
		source_a = audio_source_sample();
		source_b = audio_source_sample();
		if (source_a < 0 || source_b < 0)
		{
			return;
		}
		for (i = 0; i < RING_SIZE / 128; i++) {
			int result = audio_fill();
			if (result <= 0) {
				if (result < 0) {
					return;
				}
				break;
			}
		}
	}
	ring_seconds = duration;
	audio_enable(period);
}
_attribute_ram_code_ void cgd1_audio_irq(void)
{
	u16 value = audio_neutral;
	if (!(reg_tmr_sta & FLD_TMR_STA_TMR1))
		return;
	reg_tmr_sta = FLD_TMR_STA_TMR1;
	if (!audio_running)
		return;
	if (beep_mode) {
		if (tone_phase < sizeof(cgd1_factory_beep) - 1)
			value = cgd1_factory_beep[tone_phase++] * audio_volume;
		else
			beep_done = 1;
	} else if (ring_read != ring_write) {
		value = ring[ring_read];
		ring_read = (ring_read + 1) & (RING_SIZE - 1);
	} else {
		underruns++;
	}
	/* Keep the factory PC0/PC1 differential PWM path. All decoding,
	 * scaling and SPI access run outside this time-critical handler. */
	reg_pwm_enable &= (u8)~BIT(4);
	reg_pwm0_enable &= (u8)~BIT(0);
	reg_pwm_cycle(PWM4_ID) = audio_reference_cycle;
	reg_pwm_cycle(PWM0_ID) = audio_cycle_base | value;
	reg_pwm_enable |= BIT(4);
	reg_pwm0_enable |= BIT(0);
}

static int audio_foot_stop(void)
{
	/* During a factory multi-click session PA1 IRQ is masked. Poll each
	 * decoder chunk as well; wait for release of the click starting preview. */
	if (gpio_read(GPIO_PA1))
		foot_stop_armed = 1;
	else if (audio_running && foot_stop_armed) {
		foot_stop_armed = 0;
		foot_audio_stop = 1;
	}
	if (!foot_audio_stop)
		return 0;
	foot_audio_stop = 0;
	if (stream_active()) {
		cgd1_stop_audio();
		return 1;
	}
	/* Run the factory first-press action in main context, including snooze.
	 * The GPIO edge survives a short press and an expensive codec chunk. */
	cgd1_app_audio_press();
	return 1;
}
void cgd1_audio_service(void)
{
	if (stream_active()) {
		stream_service();
		return;
	}
	if (audio_foot_stop())
		return;
	if (!audio_running || !pcm_mode)
		return;
	/* Top up before and after the BLE main loop, and before other app
	 * work. The ring holds 128 ms even at the full 32 kHz output rate. */
	for (unsigned i = 0; i < RING_SIZE / 128; i++) {
		if (audio_foot_stop())
			break;
		int result = audio_fill();
		if (result < 0) {
			cgd1_stop_audio();
			break;
		}
		if (!result)
			break;
	}
}

static void stream_fail(u8 error)
{
	cgd1_stop_audio();
	stream.state = 4;
	stream.error = error;
}
static void stream_service(void)
{
	if (!wrk.ble_connected || wrk.ota_is_working) {
		stream_fail(1);
		return;
	}
	if (clock_time_exceed(stream_tick, 10000000)) {
		stream_fail(2);
		return;
	}
	if (audio_foot_stop()) {
		cgd1_stop_audio();
		return;
	}
	if (!audio_running && !stream.ended && stream.received - stream.consumed < 512)
		return;
	for (unsigned chunk = 0; chunk < RING_SIZE / 128; chunk++) {
		unsigned free = (ring_read - ring_write - 1) & (RING_SIZE - 1);
		if (free < 128)
			break;
		unsigned bytes = stream.received - stream.consumed;
		if (!bytes)
			break;
		if (bytes > sizeof(decoder.cache))
			bytes = sizeof(decoder.cache);
		for (unsigned i = 0; i < bytes; i++)
			decoder.cache[i] = stream.data[(stream.consumed + i) & (CGD1_STREAM_CAPACITY - 1)];
		unsigned used = 0;
		int count = cgd1_audio_stream_decode(&decoder, decoder.cache, bytes,
			&used, (int16_t *)source_samples, 128);
		if (count < 0 || (!count && stream.ended)) {
			stream_fail(3);
			return;
		}
		if (!count)
			break;
		stream.consumed += used;
		for (unsigned i = 0; i < (unsigned)count; i++)
			ring[(ring_write + i) & (RING_SIZE - 1)] = audio_pwm_sample((int32_t)(int16_t)source_samples[i] + 32768);
		__asm__ volatile ("" ::: "memory");
		ring_write = (ring_write + count) & (RING_SIZE - 1);
	}
	unsigned queued = (ring_write - ring_read) & (RING_SIZE - 1);
	if (audio_running && !stream.ended)
		stream.state = queued ? 2 : 1;
	if (!audio_running && queued >= (stream.ended ? 1 : 256)) {
		audio_enable(audio_cycle_base >> 16);
		stream.state = stream.ended ? 3 : 2;
	}
	if (stream.ended && stream.received == stream.consumed && !queued)
		cgd1_stop_audio();
}
/* Live protocol v1, PVVX command 0x90, subcommands 0x30..0x36.
 * DATA has no success notification; STATUS confirms cumulative byte positions.
 * Only this path touches the encoded RAM queue. Flash audio is unchanged. */
static unsigned stream_command(u8 sub, const u8 *p, unsigned n, u8 *out)
{
	out[2] = 1;
	if (sub == 0x30 && !n) {
		out[2] = 0;
		out[3] = 1;
		put32(out + 4, CGD1_CODEC_MASK & ~(1ul << 9));
		put32(out + 8, 16000);
		out[12] = CGD1_STREAM_CAPACITY & 255;
		out[13] = CGD1_STREAM_CAPACITY >> 8;
		out[14] = 5;
		out[15] = 1;
		return 16;
	}
	if (sub == 0x31 && n == 8) {
		u16 token = p[0] | (u16)p[1] << 8;
		if (migration_pending || ringing || stream_active() || cgd1_transfer_busy()) {
			out[2] = 2;
			return 3;
		}
		if (!token || p[7] > 5 || cgd1_audio_stream_init(&decoder, p[2], le32(p + 3)))
			return 3;
		cgd1_stop_audio();
		memset(&stream, 0, sizeof(stream));
		stream.token = token;
		stream.volume = p[7];
		stream.state = 1;
		stream_tick = clock_time();
		preview_audio = 1;
		beep_mode = pcm_mode = audio_eof = 0;
		ring_read = ring_write = 0;
		underruns = 0;
		u32 period = CLOCK_SYS_CLOCK_HZ / 32000;
		audio_volume = stream.volume;
		audio_gain = (u32)audio_volume * period * 4096 / CGD1_AUDIO_PWM_PERIOD;
		audio_cycle_base = period << 16;
		audio_neutral = audio_pwm_sample(32768);
		audio_reference_cycle = audio_cycle_base | audio_neutral;
		bls_l2cap_requestConnParamUpdate(6, 12, 0, 400);
		out[2] = 0;
		return 3;
	}
	if (sub == 0x33 && !n) {
		out[2] = 0;
		out[3] = stream.state;
		out[4] = stream.error;
		out[5] = stream.token;
		out[6] = stream.token >> 8;
		put32(out + 7, stream.received);
		put32(out + 11, stream.consumed);
		out[15] = stream.volume;
		put32(out + 16, underruns);
		return 20;
	}
	if (n < 2 || (p[0] | (u16)p[1] << 8) != stream.token)
		return 3;
	if (sub == 0x35 && n == 2) {
		if (stream_active())
			cgd1_stop_audio();
		out[2] = 0;
		return 3;
	}
	if (!stream_active()) {
		out[2] = 2;
		return 3;
	}
	if (sub == 0x32 && n > 4 && !stream.ended) {
		u16 sequence = p[2] | (u16)p[3] << 8;
		unsigned bytes = n - 4;
		if (sequence != stream.sequence || bytes > CGD1_STREAM_CAPACITY - (stream.received - stream.consumed)
			|| stream.received > 0xffff0000ul - bytes) {
			stream_fail(4);
			out[2] = 2;
			return 3;
		}
		for (unsigned i = 0; i < bytes; i++)
			stream.data[(stream.received + i) & (CGD1_STREAM_CAPACITY - 1)] = p[4 + i];
		stream.received += bytes;
		stream.sequence++;
		stream_tick = clock_time();
		return 0;
	}
	if (sub == 0x34 && n == 6) {
		if (le32(p + 2) != stream.received)
			return 3;
		stream.ended = 1;
		stream.state = 3;
		stream_tick = clock_time();
		out[2] = 0;
	}
	if (sub == 0x36 && n == 3 && p[2] <= 5) {
		stream.volume = p[2];
		audio_volume = p[2];
		audio_gain = (u32)audio_volume * (audio_cycle_base >> 16) * 4096 / CGD1_AUDIO_PWM_PERIOD;
		audio_neutral = audio_pwm_sample(32768);
		audio_reference_cycle = audio_cycle_base | audio_neutral;
		/* Already queued duty values drain in at most one ring duration. */
		out[2] = 0;
	}
	return 3;
}

static void audio_cue(void)
{
	if (settings.volume)
		audio_start(2);
}

void cgd1_ota_screen(void)
{
	cgd1_stop_audio();
	snooze_at = 0;
	if (upload.state >= 1 && upload.state <= 3)
		upload.state = 5;
	memset(display_buff, 0xff, 18);
	update_lcd();
}
static void nor_command(u8 op, u32 address, const u8 *data, unsigned n)
{
	u8 packet[260];
	u8 enable = 6;
	hal_spi(0, &enable, 1, 0, 0);
	packet[0] = op;
	packet[1] = address >> 16;
	packet[2] = address >> 8;
	packet[3] = address;
	if (n)
		memcpy(packet + 4, data, n);
	hal_spi(0, packet, 4 + n, 0, 0);
	upload.pending = 1;
	upload.busy_tick = clock_time();
}
static void upload_task(void)
{
	u8 status, cmd = 5, data[128];
	u8 fast = spi_dump.active || (upload.state >= 1 && upload.state <= 3);
	unsigned n;
	if (fast != fast_transfer) {
		/* Do not skip connection events while transferring pages. */
		bls_pm_setManualLatency(fast ? 0 : cfg.connect_latency);
		fast_transfer = fast;
	}
	if (upload.pending) {
		hal_spi(0, &cmd, 1, &status, 1);
		if (status & 1) {
			if (clock_time_exceed(upload.busy_tick, NOR_TIMEOUT_US)) {
				upload.state = 5;
				upload.failure = 1;
				upload.pending = 0;
			}
			return;
		}
		upload.pending = 0;
	}
	if (upload.state == 2 && clock_time_exceed(upload.activity_tick, 30000000)) {
		upload.failure = 2;
		upload.state = 5;
	}
	if (upload.state == 1) {
		if (upload.erased < ((upload.length + 4095) & ~4095)) {
			nor_command(0x20, upload_base() + upload.erased, 0, 0);
			upload.erased += 4096;
		} else {
			upload.state = 2;
		}
	} else if (upload.state == 3) {
		n = upload.length - upload.verify;
		if (n > sizeof(data))
			n = sizeof(data);
		if (n) {
			if (cgd1_flash_read(&board, upload_base() + upload.verify, data, n)) {
				upload.state = 5;
				return;
			}
			upload.crc = cgd1_crc32_update(upload.crc, data, n);
			upload.verify += n;
		} else if ((upload.crc ^ 0xffffffff) == upload.expected_crc) {
			struct settings previous = settings;
			u8 previous_storage_ready = settings_ready;
			u32 base = upload_base();
			struct cgd1_audio_decoder check;
			audio_memory = 0;
			if (cgd1_audio_open(&check, audio_read, &base, upload.length)) {
				upload.failure = 4;
				upload.state = 5;
				return;
			}
			ringtone_slots[upload.slot].length = upload.length;
			ringtone_slots[upload.slot].crc = upload.expected_crc;
			if (save_slots()) {
				upload.state = 5;
				return;
			}
			settings.slot = upload.slot;
			settings.reserved = upload.legacy_staging ? (settings.reserved & ~0x2c) | 0x40 : (settings.reserved & ~12) | 0x60;
			/* Do not write factory records over an unrelocated staging file.
			 * Its private EEPROM record is committed only after full CRC validation.
			 * Boot migration relocates this now-small-enough file with its journal. */
			if (upload.legacy_staging)
				settings_ready = 0;
			settings.length = upload.length;
			settings.crc = upload.expected_crc;
			if (save_settings()) {
				settings = previous;
				settings_ready = previous_storage_ready;
				upload.state = 5;
			} else {
				upload.state = 4;
				settings_ready = !upload.legacy_staging;
				settings_store();
			}
		} else {
			upload.failure = 3;
			upload.state = 5;
		}
	}
}

static void dump_task(void)
{
	u8 packet[20];
	if (!spi_dump.active)
		return;
	if (!wrk.ble_connected || !RxTxValueInCCC || wrk.ota_is_working) {
		spi_dump.active = 0;
		return;
	}
	for (unsigned burst = 0; burst < 4 && blc_ll_getTxFifoNumber() < 8; burst++) {
		packet[0] = 0x90;
		packet[1] = 0x1f;
		put32(packet + 3, spi_dump.offset);
		if (spi_dump.failed || spi_dump.offset == spi_capacity) {
			packet[2] = spi_dump.failed ? 2 : 1;
			put32(packet + 7, spi_dump.crc ^ 0xffffffff);
			if (!bls_att_pushNotifyData(RxTx_CMD_OUT_DP_H, packet, 11))
				spi_dump.active = 0;
			return;
		}
		if (spi_dump.pos == spi_dump.used) {
			unsigned count = spi_capacity - spi_dump.offset;
			if (count > sizeof(spi_dump.data))
				count = sizeof(spi_dump.data);
			if (cgd1_flash_read(&board, spi_dump.offset, spi_dump.data, count)) {
				spi_dump.failed = 1;
				continue;
			}
			spi_dump.used = count;
			spi_dump.pos = 0;
		}
		unsigned count = spi_dump.used - spi_dump.pos;
		if (count > 13)
			count = 13;
		packet[2] = 0;
		memcpy(packet + 7, spi_dump.data + spi_dump.pos, count);
		if (bls_att_pushNotifyData(RxTx_CMD_OUT_DP_H, packet, 7 + count))
			return;
		spi_dump.crc = cgd1_crc32_update(spi_dump.crc, spi_dump.data + spi_dump.pos, count);
		spi_dump.pos += count;
		spi_dump.offset += count;
	}
}

/* Factory runtime states at 0x8461E0: separate active, delayed and
 * retriggered occurrences from the persistent enabled alarm records. */
static unsigned alarm_runtime_count(u8 state)
{
	unsigned i, count = 0;
	for (i = 0; i < 16; i++)
		if (alarm_run_state[i] && (!state || alarm_run_state[i] == state))
			count++;
	return count;
}
static void alarm_pending_update(void)
{
	unsigned i;
	snooze_at = 0;
	for (i = 0; i < 16; i++) {
		if (alarm_run_state[i] == 2 && (!snooze_at || alarm_run_due[i] < snooze_at))
			snooze_at = alarm_run_due[i];
	}
}
/* Factory 0xE830/E8A0/E8D4/E91C/E95C/E990. Annunciators belong to
 * the UI state, not the audio engine; stopping audio does not clear snooze. */

/* 0x145BC. Port states 1/2/3 map to factory active states 0/1/2. */

/* 0x147B0. Closing occurrences is distinct from stopping the player. */

/* 0x14658: remove delayed/retriggered entries; disable only one-shots. */

/* 0x146A8: initial entries without snooze, not retriggered entries. */

/* 0x146FC(0): all one-shots, but only snooze-enabled repeating entries. */

/* 0x100B8, reached by 0x135A8 (natural end), never by 0x135E8 (STOP). */
static void alarm_finished(void)
{
	cgd1_app_audio_finished();
	audio_cue();
}

/* Factory 0x12D94: 30 ms binding advertisements, restored afterwards.
 * PVVX supplies advertising and GATT; the button/timer state stays local. */

/* Factory 0xE080, called immediately by 0xE158 / 0xE190, then every 500 ms. */

/* Factory 0x13AC4: one expired one-shot per invocation. A snooze-enabled
 * record survives only while its runtime occurrence is still active. */

/* Factory 0x13A04 / 0x13C08. Runtime reset must not erase the event latch. */

/* Factory 0xFD70. SDK binding cancellation is replaced by PVVX BLE. */

/* Factory 0xFDF0, not called until the UP classification interval expires. */

/* Factory 0xFE7C. Do not merge this with explicit/natural audio STOP. */
static void foot_cancel(void)
{
	cgd1_app_cancel();
}
/* Factory 0xFF2C. Pairing is adapted to the existing PVVX BLE stack. */

static void foot_reset(void)
{
	cgd1_stop_audio();
	for (unsigned i = 0; i < 16; i++) {
		struct cgd1_app_alarm empty = {0};
		struct alarm stored = {0};
		flash_write_cfg(&stored, ALARM_ID + i, sizeof(stored));
		cgd1_app_alarm_set(i, &empty);
	}
	settings.brightness = 10;
	settings.volume = 5;
	settings.language = 0;
	settings.reserved &= 0x60;
	memcpy(&cfg, &def_cfg, sizeof(cfg));
	flash_write_cfg(&cfg, EEP_ID_CFG, sizeof(cfg));
	wrk.utc_time_sec = 0x5c29cc80ul + 80 * 360;
	wrk.utc_time_sec_tick = clock_time();
	for (unsigned i = 0; i < 4; i++) {
		rtc_set_utime(wrk.utc_time_sec);
		if (!rtc_fault)
			break;
		sleep_us(500000);
	}
	night.start = 21 * 60;
	night.end = 6 * 60;
	night.enabled = 1;
	night.brightness = 5;
	light_seconds = 8;
	flash_write_cfg(&night, 0x61, sizeof(night));
	flash_write_cfg(&light_seconds, 0x62, 1);
	save_settings();
	settings_sync();
}
/* Factory 0xFFC8, 0x13918 and 0x13A04/0x13C08. */

/* Factory 0x103F0: latch the first falling edge before the pin can be
 * released again. The main loop owns all I2C, flash and audio operations. */
_attribute_ram_code_ void cgd1_foot_irq(void)
{
	if (!(reg_irq_src & FLD_IRQ_GPIO_EN))
		return;
	reg_irq_src = FLD_IRQ_GPIO_EN;
	if (initialized) {
		reg_gpio_pa_irq_en &= (u8)~BIT(1);
		foot_pending = 1;
		if (stream_active() || audio_running || ringing)
			foot_audio_stop = 1;
	}
}


static void audio_time_task(void)
{
	u32 seconds;
	if (!ringing || (preview_audio && !beep_mode))
		return;
	/* Factory playback duration is independent of RTC synchronization. */
	seconds = (u32)(clock_time() - ring_tick) / CLOCK_16M_SYS_TIMER_CLK_1S;
	if (!seconds)
		return;
	ring_tick += seconds * CLOCK_16M_SYS_TIMER_CLK_1S;
	if (seconds < ring_seconds) {
		ring_seconds -= seconds;
		return;
	}
	ring_seconds = 0;
	{
		u8 preview = preview_audio;
		cgd1_stop_audio();
		if (!preview)
			alarm_finished();
	}
}
int cgd1_busy(void)
{
	return stream_active() || settings_pending || ringing || audio_running || cgd1_app_busy() || cgd1_transfer_busy();
}
void cgd1_task(void)
{
	if (!initialized)
		return;
	if (wrk.ota_is_working) {
		if (ringing)
			cgd1_stop_audio();
		return;
	}
	settings_sync();
	light_update();
	cgd1_app_poll(!!wrk.ble_connected, ringing && !stream_active());
	u8 pressed = !gpio_read(GPIO_PA1);
	if (cgd1_transfer_busy()) {
		foot_pending = 0;
		if (!pressed)
			reg_gpio_pa_irq_en |= BIT(1);
	} else {
		if (foot_pending) {
			foot_pending = 0;
			cgd1_app_button_irq();
		}
		cgd1_app_button_poll();
	}
	last_button = pressed;
	upload_task();
	dump_task();
	if (deferred_disconnect) {
		if (cgd1_transfer_busy()) {
			deferred_disconnect_tick = clock_time();
		} else if (clock_time_exceed(deferred_disconnect_tick, 2000000)
			&& !blc_ll_getTxFifoNumber()) {
			/* Let the final CRC/status notifications drain before the alarm disconnects. */
			deferred_disconnect = 0;
			bls_ll_terminateConnection(0x13);
		}
	}
	audio_time_task();
	if (beep_done) {
		u8 preview = preview_audio;
		cgd1_stop_audio();
		if (!preview)
			alarm_finished();
	}
	cgd1_audio_service();
	if (last_second != wrk.utc_time_sec) {
		last_second = wrk.utc_time_sec;
		if (migration_pending && !stream_active() && !light_level && !cgd1_transfer_busy() && !cgd1_storage_migrate()) {
			migration_pending = 0;
			settings_ready = 1;
			settings_store();
		}
		if (!rtc_valid)
			init_rtc();
		cgd1_app_time(wrk.utc_time_sec, rtc_valid);
		cgd1_app_second();
		cgd1_app_measurement(measured_data.temp, measured_data.humi, cg_sensor_valid);
		lcd_flg.b.ext_data_buf = 0;
		SET_LCD_UPDATE();
	}
	for (unsigned i = 0; i < 16; i++) {
		uint32_t deadline;
		alarm_run_state[i] = cgd1_app_runtime(i, &deadline);
		alarm_run_due[i] = deadline;
	}
	light_update();
	if (settings_pending && !stream_active() && !light_level && !ringing && !audio_running
		&& !cgd1_transfer_busy() && clock_time_exceed(settings_save_tick, 1000000))
	{
		/* The GPIO is low for the entire internal/NOR persistence step.
		 * No flash programming occurs during the live slider preview. */
		light(0);
		if (!save_settings())
		{
			settings_pending = 0;
		}
		settings_save_tick = clock_time();
	}
	alarm_ui = cgd1_app_screen();
	alarm_event = cgd1_app_event();
	snooze_at = cgd1_app_snooze();
	bls_pm_setAppWakeupLowPower(clock_time() + 1000000 * CLOCK_16M_SYS_TIMER_CLK_1US, 1);
}

/* PVVX command 90: request [subcommand,payload], notification
 * [90,subcommand,status,payload]. Status: 0 OK, 1 format/range,
 * 2 busy, 3 unavailable/I/O. Max request fits the default ATT MTU. */
unsigned cgd1_command(const u8 *p, unsigned n, u8 *out, unsigned capacity)
{
	u8 sub, error = 1;
	unsigned size = 3;
	ensure_board();
	if (!n || capacity < 20)
		return 0;
	sub = *p++;
	if (sub == 0x11 || sub == 0x13)
		upload.activity_tick = clock_time();
	n--;
	out[0] = 0x90;
	out[1] = sub;
	if (sub >= 0x30 && sub <= 0x36) {
		if (wrk.ota_is_working || (cgd1_transfer_busy() && sub != 0x30 && sub != 0x33 && sub != 0x35)) {
			out[2] = 2;
			return 3;
		}
		return stream_command(sub, p, n, out);
	}
	if (stream_active() && sub != 0 && sub != 7 && sub != 0x17) {
		out[2] = 2;
		return 3;
	}
	if (wrk.ota_is_working) {
		out[2] = 2;
		return 3;
	}
	if (cgd1_transfer_busy()) {
		u8 read_only = (!n && (sub == 0 || sub == 1 || sub == 7 || sub == 0x17
			|| sub == 0x18 || sub == 0x19 || sub == 0x1c || sub == 0x1d))
			|| (sub == 3 && n == 1);
		u8 transfer = spi_dump.active ? (sub == 0x1e && n == 1 && !p[0]) :
			(sub == 0x11 || sub == 0x12 || sub == 0x13 || sub == 0x14 || sub == 0x15 || sub == 0x16);
		if (!read_only && !transfer) {
			out[2] = 2;
			return 3;
		}
	}
	switch (sub) {
	case 0: /* status */
		if (n)
			break;
		out[3] = 1;
		out[4] = revision;
		out[5] = rtc_valid;
		out[6] = rtc_fault;
		out[7] = nor_ok;
		out[8] = ringing;
		out[9] = upload.state;
		put32(out + 10, underruns);
		{
			u32 length, crc = 0;
			flash_read_page(0x18, 4, (u8 *)&length);
			if (length >= 32 && length <= 0x20000)
				flash_read_page(length - 4, 4, (u8 *)&crc);
			put32(out + 14, crc);
		}
		size = 18;
		error = 0;
		break;
	case 1: /* get settings */
		if (n)
			break;
		memcpy(out + 3, &settings, sizeof(settings));
		out[10] &= 3; /* Expose h12 and alarm-master state, hide time-resync bit. */
		size += sizeof(settings);
		error = 0;
		break;
	case 2: /* brightness, volume, language, reserved LE16=0, optional h12 */
		if ((n == 5 || (n == 6 && p[5] <= 1)) && p[0] <= 10 && p[1] <= 5 && p[2] <= 3) {
			struct settings previous = settings;
			if (p[3] || p[4])
				break;
			if (audio_running || (upload.state >= 1 && upload.state <= 3)) {
				error = 2;
				break;
			}
			if (settings.brightness != p[0] && light_level)
			{
				light(p[0]);
			}
			settings.brightness = p[0];
			settings.volume = p[1];
			settings.language = p[2];
			settings.time_reserved = 0;
			if (n == 6)
				settings.reserved = (settings.reserved & 0xfe) | p[5];
			error = save_settings() ? 3 : 0;
			if (error)
				settings = previous;
			light_task();
			last_alarm_minute = 0xffffffff;
		}
		break;
	case 3: /* read alarm by index */
		if (n == 1 && p[0] < 16) {
			out[3] = p[0];
			struct alarm stored;
			alarm_export(p[0], &stored);
			memcpy(out + 4, &stored, 5);
			out[8] = !!stored.snooze;
			size = 9;
			error = 0;
		}
		break;
	case 4: /* index, enabled, hour, minute, weekday mask, snooze enabled (10 minutes) */
		if (n == 6 && p[0] < 16 && p[1] <= 1 && p[2] < 24 && p[3] < 60
			&& p[4] < 128 && p[5] <= 1) {
			if (audio_running || (upload.state >= 1 && upload.state <= 3)) {
				error = 2;
				break;
			}
			if (p[1] && !rtc_valid) {
				error = 4;
				break;
			}
			struct alarm updated;
			memset(&updated, 0, sizeof(updated));
			memcpy(&updated, p + 1, 5);
			updated.snooze = p[5] ? 10 : 0;
			if (updated.enabled && !updated.days)
				updated.once_at = cgd1_app_alarm_stamp(updated.hour, updated.minute);
			error = flash_write_cfg(&updated, ALARM_ID + p[0], sizeof(updated)) == sizeof(updated) ? 0 : 3;
			if (!error) {
				alarm_import(p[0], &updated);
				settings_store();
				alarm_run_state[p[0]] = 0;
				alarm_pending_update();
				if (!alarm_runtime_count(0) && !preview_audio) {
					cgd1_stop_audio();
					alarm_event = 0;
				}
				last_alarm_minute = 0xffffffff;
				SET_LCD_UPDATE();
			}
		}
		break;
	case 5: /* play / stop */
		if (n == 1 && p[0] <= 2) {
			if (upload.state >= 1 && upload.state <= 3) {
				error = 2;
				break;
			}
			if (p[0] == 2)
				audio_cue();
			else if (p[0])
				audio_start(1);
			else {
				u8 preview = preview_audio;
				cgd1_stop_audio();
				if (!preview)
					foot_cancel();
			}
			if (p[0]) {
				preview_audio = 1;
				alarm_blink = 0;
				SET_LCD_UPDATE();
			}
			error = !p[0] || ringing ? 0 : 3;
		}
		break;
	case 6: /* Hardware diagnostics, also usable as raw Telink command 90 06. */
		if (n)
			break;
		out[3] = revision;
		out[4] = board.model;
		out[5] = board.rtc_model;
		out[6] = lcd_i2c_addr >> 1;
		out[7] = lcd_error;
		out[8] = light_level;
		out[9] = !gpio_read(GPIO_PA1);
		out[10] = last_i2c_address;
		out[11] = last_i2c_error;
		size = 12;
		error = 0;
		break;
	case 7: /* Master alarm enable: empty request reads, [1,enabled] writes. */
		if (n == 2 && p[0] == 1 && p[1] <= 1) {
			struct settings previous = settings;
			if (audio_running || (upload.state >= 1 && upload.state <= 3)) {
				error = 2;
				break;
			}
			if (p[1])
				settings.reserved &= (u8)~2;
			else {
				settings.reserved |= 2;
				snooze_at = 0;
				cgd1_stop_audio();
			}
			error = save_settings() ? 3 : 0;
			if (error)
				settings = previous;
			else {
				cgd1_app_master(p[1]);
				out[3] = !(settings.reserved & 2);
				last_alarm_minute = 0xffffffff;
				SET_LCD_UPDATE();
			}
			size = 4;
		} else if (!n) {
			out[3] = !(settings.reserved & 2);
			size = 4;
			error = 0;
		}
		break;
	case 0x10: /* begin upload, sizeLE32, CRC32LE */
		if ((n == 8 || (n == 9 && p[8] <= 2)) && le32(p) && le32(p) <= slot_bytes) {
			if (!nor_ok) {
				error = 3;
				break;
			}
			if (upload.state >= 1 && upload.state <= 3) {
				error = 2;
				break;
			}
			cgd1_stop_audio();
			cgd1_app_preview_light(0);
			memset(&upload, 0, sizeof(upload));
			upload.state = 1;
			bls_pm_setManualLatency(0);
			fast_transfer = 1;
			upload.activity_tick = clock_time();
			/* Old slots both lie below 0x80000: first write B preserves them. */
			upload.slot = n == 9 && p[8] ? p[8] - 1 :
				(settings.reserved & 0x40) ? settings.slot ^ 1 : 1;
			if (n == 9 && p[8] && settings.length) {
				u32 active = (settings.reserved & 0x20) ? slot_base(settings.slot) :
					(settings.reserved & 0x40) ? (settings.slot ? spi_capacity / 2 : 0) :
					(settings.slot ? 0x33000ul : 0x1b000ul);
				u32 start = slot_base(upload.slot);
				u32 end = start + ((le32(p) + 4095) & ~4095);
				if (start < active + settings.length && end > active) {
					struct settings previous = settings;
					settings.length = 0;
					settings.crc = 0;
					if (save_settings()) {
						settings = previous;
						error = 3;
						upload.state = 5;
						break;
					}
				}
			}
			if (!(n == 9 && p[8]) && !(settings.reserved & 0x20) && settings.length) {
				u32 old = (settings.reserved & 0x40) ? (settings.slot ? spi_capacity / 2 : 0) :
					(settings.slot ? 0x33000ul : 0x1b000ul);
				u32 end = slot_base(upload.slot) + ((le32(p) + 4095) & ~4095);
				if (slot_base(upload.slot) < old + settings.length && end > old) {
					/* An oversized old half-bank cannot be relocated before upload.
					 * Stage in the inactive OLD half; keep the current ringtone until
					 * CRC and header verification have completed. */
					if ((settings.reserved & 0x40) && upload.slot != settings.slot) {
						upload.legacy_staging = 1;
					} else {
						upload.state = 5;
						upload.failure = 5;
						error = 5;
						break;
					}
				}
			}
				ringtone_slots[upload.slot].length = 0;
			ringtone_slots[upload.slot].crc = 0;
			if (save_slots()) {
				upload.state = 5;
				error = 3;
				break;
			}
			upload.length = le32(p);
			upload.expected_crc = le32(p + 4);
			upload.crc = 0xffffffff;
			error = 0;
		}
		break;
	case 0x11: /* offsetLE32 + 1..14 PCM bytes; poll pending before next write */
		if (n >= 5 && n <= 18) {
			u32 offset = le32(p);
			unsigned count = n - 4;
			if (upload.state != 2 || upload.pending || upload.streaming) {
				error = 2;
				break;
			}
			if (offset != upload.received || count > upload.length - offset
				|| (offset & 255) + count > 256)
				break;
			nor_command(2, upload_base() + offset, p + 4, count);
			upload.received += count;
			error = 0;
		}
		break;
	case 0x15: /* Stream offsetLE32 + 1..14 PCM bytes, one ACK per page via 13. */
		if (n >= 5 && n <= 18) {
			u32 offset = le32(p);
			unsigned count = n - 4;
			upload.activity_tick = clock_time();
			if (upload.state != 2 || upload.pending) {
				error = 2;
				break;
			}
			if (offset < upload.received && count <= upload.received - offset)
				return 0;
			if (offset != upload.received || offset > upload.length
				|| count > upload.length - offset || upload.page_used + count > 256) {
				upload.state = 5;
				break;
			}
			upload.streaming = 1;
			memcpy(upload.page + upload.page_used, p + 4, count);
			upload.page_used += count;
			upload.received += count;
			if (upload.page_used == 256 || upload.received == upload.length) {
				nor_command(2, upload_base() + upload.received - upload.page_used,
					upload.page, upload.page_used);
				upload.page_used = 0;
			}
			/* No notification storm: ordered offsets + page status + final CRC. */
			return 0;
		}
		break;
	case 0x16: /* Upload capabilities; supported by firmware >= 6.7. */
		if (!n) {
			out[3] = 2;
			out[4] = 14;
			out[5] = 0;
			out[6] = 1; /* LE16: page size 256. */
			size = 7;
			error = 0;
		}
		break;
	case 0x18: /* SPI JEDEC, geometry, supported codec/rate bitmap. */
		if (!n) {
			memcpy(out + 3, spi_jedec, 3);
			put32(out + 6, spi_capacity);
			put32(out + 10, slot_bytes);
			out[14] = (u8)CGD1_CODEC_MASK;
			out[15] = (u8)(CGD1_CODEC_MASK >> 8);
			out[16] = 127; /* bits 0..6: 4 / 8 / 16 / 32 / 24 / 40 / 41 kHz. */
			out[17] = 1; /* CGDA container version. */
			size = 18;
			error = nor_ok ? 0 : 3;
		}
		break;
	case 0x1e: /* External SPI NOR dump: begin=1, cancel=0. */
		if (n == 1 && p[0] <= 1) {
			if (p[0]) {
				if (!nor_ok || ringing || cgd1_transfer_busy()) {
					error = 2;
					break;
				}
				cgd1_app_preview_light(0);
				memset(&spi_dump, 0, sizeof(spi_dump));
				spi_dump.crc = 0xffffffff;
				spi_dump.active = 1;
				bls_pm_setManualLatency(0);
				fast_transfer = 1;
			} else {
				spi_dump.active = 0;
			}
			put32(out + 3, spi_capacity);
			size = 7;
			error = 0;
		}
		break;
	case 0x1d: /* Active ringtone: 0 slot A, 1 slot B. */
		if (!n || (n == 1 && p[0] <= 1)) {
			if (n) {
				if (ringing || cgd1_transfer_busy()) {
					error = 2;
					break;
				}
				error = select_ringtone_slot(p[0]);
				if (error)
					break;
			}
			out[3] = settings.slot;
			out[4] = !!ringtone_slots[0].length;
			out[5] = !!ringtone_slots[1].length;
			size = 6;
			error = 0;
		}
		break;
	case 0x1b: /* Preview a volume without persisting slider changes. */
		if (n == 1 && p[0] >= 1 && p[0] <= 5) {
			if (upload.state >= 1 && upload.state <= 3) {
				error = 2;
				break;
			}
			u8 volume = settings.volume;
			settings.volume = p[0];
			audio_cue();
			settings.volume = volume;
			error = 0;
		}
		break;
	case 0x1c: /* Backlight timeout, seconds 0..30, persistent. */
		if (n <= 1 && (!n || p[0] <= 30)) {
			if (n) {
				u8 previous = light_seconds;
				light_seconds = p[0];
				if (flash_write_cfg(&light_seconds, 0x62, 1) != 1) {
					light_seconds = previous;
					error = 3;
					break;
				}
			}
			settings_sync();
			if (!light_seconds) {
				cgd1_app_preview_light(0);
			}
			settings_store();
			out[3] = light_seconds;
			size = 4;
			error = 0;
		}
		break;
	case 0x1a: /* Live day brightness; persist only after preview is off. */
		if (!n || (n == 1 && p[0] <= 10))
		{
			if (cgd1_transfer_busy() || audio_running)
			{
				error = 2;
				break;
			}
			if (n && settings.brightness != p[0])
			{
				settings.brightness = p[0];
				settings_pending = 1;
				settings_save_tick = clock_time();
			}
			settings_sync();
			cgd1_app_preview_light(settings.brightness);
			error = 0;
		}
		break;
	case 0x19: /* Persistent night backlight schedule; local PVVX clock. */
		if (!n || (n == 6 && p[0] <= 1 && p[1] <= 10
			&& (p[2] | p[3] << 8) < 1440 && (p[4] | p[5] << 8) < 1440)) {
			error = 0;
			if (n) {
				if (audio_running || (upload.state >= 1 && upload.state <= 3)) {
					error = 2;
					break;
				}
				u16 start = p[2] | p[3] << 8;
				u16 end = p[4] | p[5] << 8;
				u8 old[sizeof(night)];
				memcpy(old, &night, sizeof(night));
				night.enabled = p[0];
				night.brightness = p[1];
				night.start = start;
				night.end = end;
				if (flash_write_cfg(&night, 0x61, sizeof(night)) != sizeof(night)) {
					memcpy(&night, old, sizeof(night));
					error = 3;
				}
				light_task();
				settings_store();
			}
			out[3] = settings.brightness;
			out[4] = night.enabled;
			out[5] = night.brightness;
			out[6] = night.start;
			out[7] = night.start >> 8;
			out[8] = night.end;
			out[9] = night.end >> 8;
			size = 10;
		}
		break;
	case 0x17: /* Runtime clock and nearest armed deadline, native PVVX time. */
		if (!n) {
			u32 next = cgd1_app_next();
			out[3] = rtc_valid;
			out[4] = rtc_fault;
			out[5] = !(settings.reserved & 2);
			out[6] = ringing;
			out[7] = !!snooze_at;
			put32(out + 8, wrk.utc_time_sec);
			put32(out + 12, next);
			size = 16;
			error = 0;
		}
		break;
	case 0x12: /* begin readback verification */
		if (n)
			break;
		if (upload.state != 2 || upload.pending || upload.received != upload.length || upload.page_used) {
			error = 2;
			break;
		}
		upload.state = 3;
		error = 0;
		break;
	case 0x13: /* progress */
		if (n)
			break;
		out[3] = upload.state;
		out[4] = upload.pending;
		put32(out + 5, upload.received);
		put32(out + 9, upload.erased);
		put32(out + 13, upload.verify);
		out[17] = upload.failure;
		size = 18;
		error = 0;
		break;
	case 0x14: /* abort; active slot remains intact */
		if (!n) {
			if (upload.pending) {
				error = 2;
				break;
			}
			upload.state = 0;
			error = 0;
		}
		break;
	}
	out[2] = error;
	SET_LCD_UPDATE();
	return size;
}
void cgd1_hw_light(uint8_t level)
{
	if (level && (cgd1_transfer_busy() || preview_audio))
		return;
	if (level)
	{
		light_pwm_fault = 0;
	}
	if (!alarm_blink)
		light(level);
}
void cgd1_hw_audio(uint8_t start)
{
	if (start) {
		if (cgd1_transfer_busy())
			return;
		audio_start(0);
		cgd1_app_preview_light(0);
		alarm_blink = ringing;
		blink_on = 1;
		blink_tick = clock_time();
		light_update();
	} else {
		cgd1_stop_audio();
	}
}
void cgd1_hw_binding(uint8_t enabled)
{
	if (enabled == 2) {
		bls_ll_setAdvEnable(0);
	} else {
		set_adv_con_time(!enabled);
		if (!wrk.ble_connected)
			bls_ll_setAdvEnable(1);
	}
}
void cgd1_hw_disconnect(void)
{
	if (cgd1_transfer_busy()) {
		deferred_disconnect = 1;
		deferred_disconnect_tick = clock_time();
	} else {
		bls_ll_terminateConnection(0x13);
	}
}
void cgd1_hw_reset(uint8_t reboot)
{
	if (reboot)
		start_reboot();
	else
		foot_reset();
}
void cgd1_hw_alarm_saved(void)
{
	for (unsigned i = 0; i < 16; i++)
	{
		struct alarm updated, stored;
		alarm_export(i, &updated);
		int length = flash_read_cfg(&stored, ALARM_ID + i, sizeof(stored));
		if (length != sizeof(stored) || memcmp(&updated, &stored, sizeof(stored)))
			flash_write_cfg(&updated, ALARM_ID + i, sizeof(updated));
	}
	settings_store();
	SET_LCD_UPDATE();
}
void cgd1_hw_master_saved(uint8_t enabled)
{
	if (enabled)
		settings.reserved &= (u8)~2;
	else
		settings.reserved |= 2;
	save_settings();
	SET_LCD_UPDATE();
}
void cgd1_hw_flush(void)
{
	SET_LCD_UPDATE();
}
uint32_t cgd1_hw_tick(void)
{
	return clock_time();
}
uint8_t cgd1_hw_button(void)
{
	return !!gpio_read(GPIO_PA1);
}
int cgd1_audio_critical(void)
{
	return 0; /* SDK RF/timer interrupts must always be acknowledged. */
}
int cgd1_sensor_ready(void)
{
	return cg_sensor_valid;
}
void cgd1_sensor_result(int valid)
{
	cg_sensor_valid = !!valid;
	cgd1_app_measurement(measured_data.temp, measured_data.humi, cg_sensor_valid);
}

/* Factory record sectors precede the two dynamically sized audio banks. */
static int settings_write(u32 address, const u8 *data, unsigned count)
{
	u8 old[147];
	if (!cgd1_flash_read(&board, address, old, count) && !memcmp(old, data, count))
		return 0;
	if (cgd1_flash_erase(&board, address))
		return -1;
	return cgd1_flash_write(&board, address, data, count);
}
static int settings_valid(u8 *data, unsigned size, unsigned offset)
{
	return data[0] == 0x55 && cgd1_settings_crc(data, size, offset)
		== (data[offset] | (u16)data[offset + 1] << 8);
}
static void settings_load(void)
{
	u8 data[147], marker[3];
	if (settings_loaded)
		return;
	if ((cgd1_flash_read(&board, 0, data, 49) || !settings_valid(data, 49, 47))
		&& (cgd1_flash_read(&board, 0x2000, data, 49) || !settings_valid(data, 49, 47)))
		return;
	if (data[1] <= 5 && (data[19] & 15) <= 10 && (data[19] >> 4) <= 10) {
		if (data[21] == 'P' && data[22] >= 0x79)
			settings.reserved |= 0x60;
		if (!cgd1_flash_read(&board, 0x5000, marker, 3) && settings_valid(marker, 3, 1))
			settings.slot = 1;
		else if (!cgd1_flash_read(&board, 0x4000, marker, 3) && settings_valid(marker, 3, 1))
			settings.slot = 0;
		settings.volume = data[1];
		settings.language = data[4];
		settings.reserved = (settings.reserved & ~3) | !data[5] | (data[8] ? 2 : 0);
		cfg.flg.temp_F_or_C = !data[6];
		night.start = data[9] * 60 + data[10];
		night.end = data[11] * 60 + data[12];
		if (night.enabled)
			night.brightness = data[19] & 15;
		settings.brightness = data[19] >> 4;
		light_seconds = data[18] <= 30 ? data[18] : 8;
		settings.length = le32(data + 23);
		settings.crc = le32(data + 13);
		if (settings.length == UINT32_MAX)
			settings.length = 0;
	}
	if ((cgd1_flash_read(&board, 0x1000, data, 147) || !settings_valid(data, 147, 1))
		&& (cgd1_flash_read(&board, 0x3000, data, 147) || !settings_valid(data, 147, 1)))
		return;
	for (unsigned i = 0; i < 16; i++) {
		u8 *a = data + 3 + i * 9;
		struct alarm stored = {0};
		stored.enabled = a[0] == 1;
		stored.hour = a[1] < 24 ? a[1] : 0;
		stored.minute = a[2] < 60 ? a[2] : 0;
		stored.days = a[3] < 128 ? a[3] : 0;
		stored.snooze = a[4] & 1 ? 10 : 0;
		stored.once_at = le32(a + 5);
		alarm_import(i, &stored);
	}
}
static void settings_store(void)
{
	u8 parameters[49], records[147], marker[3];
	if (!settings_ready || !nor_ok || light_level || stream_active() || audio_running || upload.pending || spi_dump.active)
		return;
	settings_sync();
	cgd1_app_records(parameters, records, settings.length, settings.crc);
	if (settings_write(0, parameters, 49) || settings_write(0x2000, parameters, 49)
		|| settings_write(0x1000, records, 147) || settings_write(0x3000, records, 147))
		return;
	for (unsigned bank = 0; bank < 2; bank++) {
		marker[0] = settings.length && settings.slot == bank ? 0x55 : 0;
		marker[1] = marker[2] = 0;
		u16 crc = cgd1_settings_crc(marker, 3, 1);
		marker[1] = crc;
		marker[2] = crc >> 8;
		if (settings_write(0x4000 + bank * 0x1000, marker, 3))
			return;
	}
}
static int cgd1_storage_migrate(void)
{
	static u8 sector[4096];
	u32 old_base, new_base, count, block;
	struct migration_record {
		u32 magic, old_base, new_base, length, slot, block;
	} journal;
	if (settings.reserved & 0x20)
		return settings.length <= slot_bytes ? 0 : -1;
	if (settings.length > slot_bytes)
		return -1;
	old_base = (settings.reserved & 0x40) ? (settings.slot ? spi_capacity / 2 : 0) :
		(settings.slot ? 0x33000ul : 0x1b000ul);
	new_base = slot_base(settings.slot);
	count = (settings.length + 4095) / 4096;
	if (settings.length && (old_base >= spi_capacity || settings.length > spi_capacity - old_base))
		return -1;
	if (flash_read_cfg(&journal, 0x67, sizeof(journal)) == sizeof(journal)
		&& journal.magic == 0x39444743 && journal.length == settings.length
		&& journal.slot == settings.slot && journal.old_base == old_base
		&& journal.new_base == new_base && journal.block <= count) {
		block = journal.block;
	} else {
		journal.magic = 0x39444743;
		journal.old_base = old_base;
		journal.new_base = new_base;
		journal.length = settings.length;
		journal.slot = settings.slot;
		journal.block = 0;
		if (flash_write_cfg(&journal, 0x67, sizeof(journal)) != sizeof(journal))
			return -1;
		block = 0;
	}
	for (; block < count; block++) {
		u32 offset = (new_base > old_base ? count - block - 1 : block) * 4096;
		unsigned bytes = settings.length - offset;
		if (bytes > sizeof(sector))
			bytes = sizeof(sector);
		memset(sector, 255, sizeof(sector));
		if (cgd1_flash_read(&board, old_base + offset, sector, bytes)
			|| cgd1_flash_erase(&board, new_base + offset)
			|| cgd1_flash_write(&board, new_base + offset, sector, bytes))
			return -1;
		journal.block = block + 1;
		if (flash_write_cfg(&journal, 0x67, sizeof(journal)) != sizeof(journal))
			return -1;
	}
	settings.reserved |= 0x60;
	return flash_write_cfg(&settings, CFG_ID, sizeof(settings)) == sizeof(settings) ? 0 : -1;
}

void cgd1_hw_i2c(void)
{
	init_i2c();
}
int cgd1_audio_battery_allowed(void)
{
	return !audio_running;
}
#endif

#if DEVICE_TYPE == DEVICE_CGD1
void cgd1_hw_preview(void)
{
	if (!ringing && !cgd1_transfer_busy())
		audio_start(1);
}
#endif

#if DEVICE_TYPE == DEVICE_CGD1
uint32_t cgd1_hw_irq_source(void)
{
	return reg_irq_src;
}
void cgd1_key_irq_mask(void)
{
	reg_irq_src = FLD_IRQ_GPIO_EN;
	reg_gpio_pa_irq_en &= (u8)~BIT(1);
}
void cgd1_key_irq_rearm(void)
{
	reg_gpio_pa_irq_en |= BIT(1);
	cpu_set_gpio_wakeup(GPIO_PA1, 0, 1);
}
#endif

