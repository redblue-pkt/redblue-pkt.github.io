#include "cgd1/cgd1_internal.h"
#include "cgd1/cgd1_crc.h"

struct cgd1_app_state cgd1_state;
uint8_t controller_state, last_celsius;

static uint8_t sleep_locks, connected_before, terminate_pending, time_ready;
static uint8_t sensor_valid, press_stopped_audio, early_audio_press;
static int16_t sensor_temperature;
static uint16_t sensor_humidity;
static uint32_t now_epoch, previous_calendar_minute = UINT32_MAX;
struct app_timer {
	cgd1_timer_callback_t callback;
	uint32_t period, tick;
};
static struct app_timer timers[8];
static void (*deferred[3])(void);
void cgd1_key_first_press(void)
{
	if (early_audio_press) {
		early_audio_press = 0;
		return;
	}
	press_stopped_audio = cgd1_audio_is_playing();
	cgd1_key_stop();
}
void cgd1_key_double_press(void)
{
	uint8_t idle = cgd1_state.screen == 1 && !press_stopped_audio
		&& !cgd1_state.audio_playing && !cgd1_alarm_count_event_type1()
		&& !cgd1_alarm_count_event_type2()
		&& !cgd1_state.alarm_active;
	cgd1_key_cancel(1);
	if (idle)
		cgd1_hw_preview();
}

uint32_t cgd1_weekday_monday_one(uint32_t weekday)
{
	return (weekday & 255) ? weekday & 255 : 7;
}
bool cgd1_board_uses_at8372(void)
{
	return cgd1_state.revision < 2;
}
int cgd1_rtc_initialization_ready(void)
{
	return time_ready;
}
int cgd1_app_epoch(void)
{
	return time_ready ? now_epoch : 0;
}
void cgd1_power_lock(uint32_t reason)
{
	sleep_locks |= 1u << reason;
}
void cgd1_power_unlock(uint32_t reason)
{
	sleep_locks &= ~(1u << reason);
}
uint32_t cgd1_soft_timer_add(cgd1_timer_callback_t callback, int period)
{
	for (unsigned i = 0; i < 8; i++) {
		if (!timers[i].callback || timers[i].callback == callback) {
			timers[i].callback = callback;
			timers[i].period = period * 16u;
			timers[i].tick = cgd1_hw_tick();
			return 1;
		}
	}
	return 0;
}

uint32_t cgd1_soft_timer_remove_callback(cgd1_timer_callback_t callback)
{
	for (unsigned i = 0; i < 8; i++) {
		if (timers[i].callback == callback)
			timers[i].callback = 0;
	}
	return 0;
}
uint32_t cgd1_display_flush(void)
{
	cgd1_hw_flush();
	return 1;
}
uint8_t cgd1_audio_is_playing(void)
{
	return cgd1_state.audio_playing;
}
void cgd1_sound_stop(void)
{
	cgd1_hw_audio(0);
	cgd1_state.audio_playing = 0;
}
void cgd1_ble_stop_advertising(void)
{
	cgd1_hw_binding(2);
	cgd1_state.advertising = 0;
}
void cgd1_ble_set_binding_mode(char enabled)
{
	cgd1_state.binding_mode = enabled;
	if (controller_state == 8 || cgd1_audio_is_playing())
		return;
	cgd1_state.advertising = 1;
	cgd1_hw_binding(enabled);
}
uint8_t cgd1_ble_get_binding_mode(void)
{
	return cgd1_state.binding_mode;
}
void cgd1_lcd_cancel_alarm_blink(void)
{
	cgd1_state.bluetooth_blink = 0;
}
void cgd1_alarm_start_sound_and_light(void)
{
	cgd1_led_turn_on(0, cgd1_led_get_brightness());
	if (!cgd1_state.alarm_active) {
		cgd1_state.alarm_active = 1;
		cgd1_on_audio_started();
		cgd1_hw_audio(1);
	}
}
void cgd1_binding_begin_with_blink(void)
{
	if (cgd1_lcd_binding_blink_start())
		cgd1_ble_set_binding_mode(1);
}
uint32_t cgd1_ble_enqueue_deferred_callback(void (*callback)(void))
{
	for (unsigned i = 0; i < 3; i++) {
		if (!deferred[i]) {
			deferred[i] = callback;
			return 1;
		}
	}
	return 0;
}
uint32_t cgd1_disconnect(uint32_t reason)
{
	(void)reason;
	terminate_pending = 1;
	cgd1_hw_disconnect();
	return 0;
}
void cgd1_user_data_reset(void)
{
	cgd1_hw_reset(0);
}
void cgd1_binding_clear_and_reboot(void)
{
	cgd1_hw_reset(1);
}
uint32_t cgd1_i2c_initialize(void)
{
	cgd1_hw_i2c();
	return 1;
}

void cgd1_app_init(uint8_t revision)
{
	memset(timers, 0, sizeof(timers));
	memset(deferred, 0, sizeof(deferred));
	memset(&cgd1_state, 0, sizeof(cgd1_state));
#ifdef CGD1_TELINK
	extern uint8_t display_buff[];
	cgd1_state.lcd = display_buff;
#endif

	sleep_locks = connected_before = terminate_pending = press_stopped_audio = 0;
	cgd1_state.revision = revision;
	cgd1_state.lcd_driver = revision == 2;
	cgd1_state.colon_enabled = 1;
	cgd1_state.config.audio_play_time = 600;
	cgd1_state.config.automatic_time_correction = 1;
	cgd1_state.config.ble_adv_interval = 999;
	cgd1_state.config.reserved_15[0] = 'P';
	cgd1_state.config.reserved_15[1] = 0x85;
	cgd1_state.screen = 1;
	cgd1_state.advertising = 1;
	previous_calendar_minute = UINT32_MAX;
	cgd1_lcd_clear();
}
void cgd1_app_configure(const struct cgd1_app_config *c)
{
	cgd1_state.config.audio_volume = c->volume;
	cgd1_state.config.led_brightness = (c->brightness << 4) | (c->night_enabled ? c->night_brightness : c->brightness);
	cgd1_state.config.led_on_time = c->light_seconds;
	cgd1_state.config.chinese_language = c->language;
	cgd1_state.config.hour_system_24 = !c->h12;
	cgd1_state.config.celsius = c->celsius;
	cgd1_state.config.alarms_all_off = !c->master;
	cgd1_state.config.night_start_hour = c->night_start / 60;
	cgd1_state.config.night_start_minute = c->night_start % 60;
	cgd1_state.config.night_end_hour = c->night_end / 60;
	cgd1_state.config.night_end_minute = c->night_end % 60;
	if (cgd1_state.screen != 6)
		cgd1_alarm_refresh_icon();
}
void cgd1_app_time(uint32_t epoch, uint8_t ready)
{
	struct cgd1_rtc_time next;
	now_epoch = epoch;
	time_ready = ready;
	cgd1_state.rtc_init_retries = ready ? 0 : 2;
	if (!ready)
		return;
	cgd1_epoch_to_rtc(epoch, &next);
	cgd1_state.time = next;
	if (!cgd1_state.next_mode && epoch / 60 != previous_calendar_minute) {
		previous_calendar_minute = epoch / 60;
		if (next.second < 2)
			cgd1_alarm_evaluate_minute(&next);
	}
}
void cgd1_app_measurement(int16_t temperature, uint16_t humidity, uint8_t valid)
{
	sensor_temperature = temperature;
	sensor_humidity = humidity;
	sensor_valid = valid;
	cgd1_state.raw_temperature = temperature;
	cgd1_state.raw_humidity = humidity;
}
void cgd1_app_audio_press(void)
{
	cgd1_state.audio_playing = 1;
	press_stopped_audio = 1;
	cgd1_key_stop();
	early_audio_press = 1;
}
void cgd1_app_button_irq(void)
{
	cgd1_button_wakeup_irq(1);
}
void cgd1_app_button_poll(void)
{
	if (cgd1_state.button.wakeup_pending || (!cgd1_state.button.scan_pending && !cgd1_hw_button()))
		cgd1_button_begin_scan();
	if (cgd1_state.button.scan_pending)
		cgd1_button_scan_task();
	if (!cgd1_state.button.scan_pending && !cgd1_state.button.wakeup_pending)
		early_audio_press = 0;
}
void cgd1_app_poll(uint8_t connected, uint8_t playing)
{
	cgd1_state.audio_playing = playing;
	controller_state = connected ? 8 : 1;
	if (connected && !connected_before) {
		cgd1_binding_end();
		cgd1_on_ble_connected();
	}
	connected_before = connected;
	if (!connected && terminate_pending) {
		terminate_pending = 0;
		for (unsigned i = 0; i < 3; i++) {
			void (*callback)(void) = deferred[i];
			deferred[i] = 0;
			if (callback)
				callback();
		}
	}
	for (unsigned i = 0; i < 8; i++) {
		if (timers[i].callback && (uint32_t)(cgd1_hw_tick() - timers[i].tick) > timers[i].period) {
			cgd1_timer_callback_t callback = timers[i].callback;
			timers[i].tick = cgd1_hw_tick();
			if ((int32_t)callback() == -1 && timers[i].callback == callback)
				timers[i].callback = 0;
		}
	}
}
void cgd1_app_audio_stopped(void)
{
	cgd1_state.audio_playing = 0;
	cgd1_on_audio_finished();
}
void cgd1_app_audio_finished(void)
{
	cgd1_app_audio_stopped();
	cgd1_on_alarm_finished();
}
void cgd1_app_alarm_set(unsigned index, const struct cgd1_app_alarm *a)
{
	if (index >= 16)
		return;
	volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
	slot->enabled = a->enabled;
	slot->hour = a->hour;
	slot->minute = a->minute;
	slot->repeat_raw = a->days;
	slot->flags_raw = !!a->snooze;
	slot->timestamp = a->timestamp;
	cgd1_alarm_remove_events(index);
	cgd1_alarm_refresh_icon();
}
void cgd1_app_alarm_get(unsigned index, struct cgd1_app_alarm *a)
{
	if (index >= 16)
		return;
	volatile struct cgd1_alarm_slot *slot = &cgd1_state.alarms.slots[index];
	a->enabled = slot->enabled;
	a->hour = slot->hour;
	a->minute = slot->minute;
	a->days = slot->repeat_raw;
	a->snooze = !!(slot->flags_raw & 1);
	a->timestamp = slot->timestamp;
}
void cgd1_app_master(uint8_t enabled)
{
	if (enabled)
		cgd1_alarm_switch_all_on(1);
	else
		cgd1_alarm_switch_all_off(1);
}
void cgd1_app_cancel(void)
{
	cgd1_key_cancel(0);
}
static void render_alarm_lcd(void)
{
	uint8_t screen = cgd1_state.screen;
	uint8_t language = cgd1_state.config.chinese_language;
	cgd1_lcd_snooze_label(0, 3);
	cgd1_lcd_stop_label(0, 3);
	if (screen >= 3)
		cgd1_lcd_snooze_label(1, language);
	if (screen == 3)
		cgd1_lcd_stop_label(1, language);
	/* Screen 2 restores the cached sensor state before an error overlay. */
	if (screen == 2)
		cgd1_lcd_restore_sensor_values(0);
	cgd1_state.sensors_hidden = 0;
	if (sensor_valid)
		cgd1_lcd_show_sensor_values(sensor_temperature / 10,
			sensor_humidity / 10, cgd1_state.config.celsius, 1);
	else
		cgd1_lcd_sensor_error_2(cgd1_state.config.celsius);
	cgd1_state.date_hidden = 0;
	cgd1_lcd_show_datetime(cgd1_state.time, language,
		cgd1_state.config.hour_system_24);
	cgd1_lcd_update_bluetooth();
}

void cgd1_app_copy_lcd(uint8_t *output)
{
	if (time_ready && !cgd1_state.screen_locked && !cgd1_state.next_mode
		&& cgd1_state.screen >= 2 && cgd1_state.screen <= 4)
	{
		render_alarm_lcd();
	}
	else
	{
		if (!cgd1_state.screen_locked) {
			if (!cgd1_state.next_mode && cgd1_state.screen != 1)
				cgd1_lcd_show_datetime(cgd1_state.time, cgd1_state.config.chinese_language, cgd1_state.config.hour_system_24);
			if (cgd1_state.sensors_hidden)
				cgd1_lcd_clear_sensor_values();
			else if (sensor_valid)
				cgd1_lcd_show_sensor_values(sensor_temperature / 10, sensor_humidity / 10, cgd1_state.config.celsius, 1);
			else
				cgd1_lcd_sensor_error_2(cgd1_state.config.celsius);
			cgd1_ui_redraw();
			
			if (cgd1_state.screen >= 2 && cgd1_state.screen <= 4) {
				cgd1_lcd_restore_date(0, 0);
				cgd1_state.sensors_hidden = 0;
				if (sensor_valid)
					cgd1_lcd_show_sensor_values(sensor_temperature / 10,
						sensor_humidity / 10, cgd1_state.config.celsius, 1);
				else
					cgd1_lcd_sensor_error_2(cgd1_state.config.celsius);
			}
			cgd1_lcd_update_bluetooth();
			if (!time_ready)
				cgd1_lcd_show_invalid_time();
		}
		if (cgd1_state.screen != 6)
		{
			if (time_ready && (cgd1_state.screen != 1 || cgd1_state.screen_locked))
			{
				/* Alarm redraw may have hidden the date earlier in this frame.
				 * Keep the calendar visible regardless of legacy saved flags. */
				cgd1_state.date_hidden = 0;
				cgd1_lcd_show_date(cgd1_state.time.year_since_2000,
					cgd1_state.time.month, cgd1_state.time.day, 0);
				cgd1_lcd_show_weekday(cgd1_state.time.weekday,
					cgd1_state.config.chinese_language);
			}
		}
	}
	if (output != cgd1_state.lcd)
		memcpy(output, cgd1_state.lcd, 18);
}
void cgd1_app_second(void)
{
	cgd1_lcd_colon_tick(1000);
}
void cgd1_app_wake_light(void)
{
	cgd1_led_turn_on(0, cgd1_led_get_brightness());
}
uint8_t cgd1_app_screen(void)
{
	return cgd1_state.screen;
}
uint8_t cgd1_app_busy(void)
{
	return sleep_locks || cgd1_state.button.scan_pending || cgd1_state.button.wakeup_pending || terminate_pending;
}
uint8_t cgd1_app_event(void)
{
	return cgd1_state.alarm_active;
}
uint8_t cgd1_app_runtime(unsigned index, uint32_t *timestamp)
{
	for (unsigned i = 0; i < 16; i++) {
		volatile struct cgd1_alarm_event *e = &cgd1_state.alarms.events[i];
		if (e->enabled && e->slot == index) {
			*timestamp = e->timestamp;
			return e->event_type + 1;
		}
	}
	*timestamp = 0;
	return 0;
}
uint32_t cgd1_app_snooze(void)
{
	uint32_t next = 0;
	for (unsigned i = 0; i < 16; i++) {
		volatile struct cgd1_alarm_event *e = &cgd1_state.alarms.events[i];
		if (e->enabled && e->event_type == 1 && (!next || e->timestamp < next))
			next = e->timestamp;
	}
	return next;
}
uint32_t cgd1_app_alarm_stamp(uint8_t hour, uint8_t minute)
{
	struct cgd1_rtc_time now = cgd1_state.time;
	return cgd1_alarm_next_one_shot_epoch(&now, hour, minute);
}
uint32_t cgd1_app_next(void)
{
	struct cgd1_rtc_time next;
	struct cgd1_calendar date;
	if (!time_ready || !cgd1_alarm_get_next((uint8_t *)&next, now_epoch, 0))
		return 0;
	cgd1_rtc_to_calendar(&next, &date);
	return cgd1_calendar_to_epoch(&date);
}
static uint16_t battery_average;
static uint32_t battery_sum;
static uint8_t battery_count, battery_low, battery_percent = 100;
uint16_t cgd1_app_battery(uint16_t sample)
{
	if (!battery_average)
		battery_average = sample;
	if (battery_count < 5) {
		battery_sum += sample;
		battery_count++;
	} else {
		battery_average = battery_sum / battery_count;
		battery_count = 0;
		battery_sum = 0;
	}
	battery_percent = battery_average >= 3001 ? 100 : battery_average > 2200 ? (battery_average - 2200) >> 3 : 0;
	if (battery_average < 2400)
		battery_low = 1;
	else if (battery_average >= 2551)
		battery_low = 0;
	return battery_average;
}
uint8_t cgd1_app_battery_low(void)
{
	return battery_low;
}
uint8_t cgd1_app_battery_level(void)
{
	return battery_percent;
}
static void record_crc(uint8_t *data, unsigned size, unsigned offset)
{
	uint16_t crc = cgd1_settings_crc(data, size, offset);
	data[offset] = crc;
	data[offset + 1] = crc >> 8;
}
void cgd1_app_records(uint8_t settings[49], uint8_t alarms[147], uint32_t length, uint32_t crc)
{
	cgd1_state.config.valid_marker = 0x55;
	cgd1_state.config.audio_file_size = length;
	cgd1_state.config.audio_data_signature = crc;
	memcpy(settings, (void *)(&cgd1_state.config), 49);
	record_crc(settings, 49, 47);
	alarms[0] = 0x55;
	memcpy(alarms + 3, (void *)cgd1_state.alarms.slots, 144);
	record_crc(alarms, 147, 1);
}

uint8_t cgd1_app_brightness(void)
{
	return cgd1_led_get_brightness();
}
