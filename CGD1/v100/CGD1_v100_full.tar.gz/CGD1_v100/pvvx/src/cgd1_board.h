#ifndef CGD1_BOARD_H
#define CGD1_BOARD_H
void cgd1_task(void);
void cgd1_audio_service(void);
void cgd1_boot_display(void);
void cgd1_prepare_sleep(void);
void cgd1_audio_irq(void);
void cgd1_foot_irq(void);
int cgd1_busy(void);
int cgd1_transfer_busy(void);
int cgd1_audio_critical(void);
int cgd1_audio_battery_allowed(void);
int cgd1_sensor_ready(void);
void cgd1_sensor_result(int valid);
unsigned cgd1_command(const unsigned char *, unsigned, unsigned char *, unsigned);
#endif
